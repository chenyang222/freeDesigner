define('src/page/components/footer/footer.vue', function(require, exports, module) {

  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  
  'use strict';
  
  Object.defineProperty(exports, '__esModule', {
      value: true
  });
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _srcAssetsJsConstant = require('src/assets/js/constant');
  
  var _srcAssetsJsConstant2 = _interopRequireDefault(_srcAssetsJsConstant);
  
  var _lodash = require('node_modules/lodash/lodash');
  
  var _lodash2 = _interopRequireDefault(_lodash);
  
  exports['default'] = {
      data: function data() {
          return _lodash2['default'].merge({}, _srcAssetsJsConstant2['default'].PATH);
      }
  };
  module.exports = exports['default'];
  var __vue__options__;
  if(exports && exports.__esModule && exports.default){
    __vue__options__ = exports.default;
  }else{
    __vue__options__ = module.exports;
  }
  __vue__options__.template = "<footer __vuec__935773be=\"__vuec__935773be\" class=\"footer\"><div class=\"container\"><div class=\"l\"><div class=\"item\"><a href=\"/\">首页</a><a href=\"{{ORDER_PUB_MANAGEMENT}}\">我是雇主</a><a href=\"{{ORDER_INTEGRAL}}\">积分充值</a><a href=\"/about.html\">关于平台</a></div><div class=\"item\"><a href=\"{{ORDER_DEMAND}}\">需求池</a><a href=\"{{ORDER_APPLY_MANAGEMENT}}\">我是工作者</a><a href=\"{{ORDER_INTEGRAL}}\">积分管理</a><a href=\"{{USER_PROFILE}}\">个人中心</a></div></div><div class=\"r\"><div class=\"qrcode\"><img src=\"/src/page/components/footer/weixin.png\"/><p>关注我们</p></div><div class=\"info\"><p>自由盟邦网服务热线</p><h4>010-53393309</h4><p>客服QQ<a href=\"http://shang.qq.com/email/stop/email_stop.html?qq=1776261265&amp;sig=a1c657365db7e82805ea4b2351081fc3ebcde159f8ae49b1&amp;tttt=1\"><img src=\"/src/page/components/footer/qq.png\"/><span>1776261265</span></a></p><p>周一至周五：09:00—21:00</p><p>周末及节假日：09:00—08:00</p></div></div></div><div class=\"bottom\"><p>Copyright © 2016 - 2020 free-designer.cn All rights reserved.自由工程协作平台©版权所有.</p><p>京ICP备17002726号-1</p></div></footer>"
  

});
