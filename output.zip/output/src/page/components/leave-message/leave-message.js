define('src/page/components/leave-message/leave-message.vue', function(require, exports, module) {

  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  
  'use strict';
  
  Object.defineProperty(exports, '__esModule', {
      value: true
  });
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _srcPublicModalModal = require('src/public/modal/modal.vue');
  
  var _srcPublicModalModal2 = _interopRequireDefault(_srcPublicModalModal);
  
  var _srcAssetsJsConstant = require('src/assets/js/constant');
  
  var _srcAssetsJsConstant2 = _interopRequireDefault(_srcAssetsJsConstant);
  
  var _srcAssetsJsApi = require('src/assets/js/api');
  
  var _srcAssetsJsApi2 = _interopRequireDefault(_srcAssetsJsApi);
  
  var _srcPageMixins = require('src/page/mixins');
  
  var _srcPageMixins2 = _interopRequireDefault(_srcPageMixins);
  
  var _jquery = require('node_modules/jquery/dist/jquery');
  
  var _jquery2 = _interopRequireDefault(_jquery);
  
  exports['default'] = {
      mixins: [_srcPageMixins2['default']],
      props: ['aid', 'show'],
      components: {
          modal: _srcPublicModalModal2['default']
      },
      computed: {
          url: function url() {
              if (!this.aid) return;
              return _srcAssetsJsConstant2['default'].API.APPLY_RECORDS + this.aid + _srcAssetsJsConstant2['default'].API.ORDER_COMMENTS;
          }
      },
      watch: {
          show: function show(val) {
              val && this.scrollBottom();
          },
          aid: function aid() {
              // debugger;
              this.reloadAsyncData();
          }
      },
      asyncData: function asyncData(resolve) {
          setTimeout(function () {
              window.userStat.done(function () {
                  this.uid = this.data.id;
                  resolve(this);
              });
          }, 200);
          this.fetch().done(function () {
              this.messages = this.data;
              resolve(this);
          });
      },
      methods: {
          fetch: function fetch() {
              var url = this.url;
              return _srcAssetsJsApi2['default'].get({
                  url: url
              });
          },
          scrollBottom: function scrollBottom() {
              (0, _jquery2['default'])('.messages').scrollTop(10000);
          },
          // 3. 发单人留言
          postComment: function postComment() {
              var self = this;
              _srcAssetsJsApi2['default'].post({
                  url: this.url,
                  data: {
                      message: this.leave_message
                  }
              }).done(function () {
                  self.reloadAsyncData();
                  self.leave_message = '';
                  self.scrollBottom();
              });
          }
      },
      data: function data() {
          return {
              uid: '',
              leave_message: '',
              messages: []
          };
      }
  };
  module.exports = exports['default'];
  var __vue__options__;
  if(exports && exports.__esModule && exports.default){
    __vue__options__ = exports.default;
  }else{
    __vue__options__ = module.exports;
  }
  __vue__options__.template = "<modal :show.sync=\"show\" :css=\"{width: 480, height: 600}\"><h3 slot=\"header\" class=\"fl\"><a>留言记录</a></h3><div slot=\"body\" __vuec__b59b0aa1=\"__vuec__b59b0aa1\" class=\"slot-body mt-40\"><ul class=\"messages mt-30\"><li v-for=\"message in messages\" class=\"mt-30\"><div v-if=\"uid !== message.user.id\" class=\"message-left\"><div class=\"name fl\">{{message.user.name}}：</div><div class=\"message fl\">{{message.message}}</div></div><div v-if=\"uid === message.user.id\" class=\"message-right fr\"><div class=\"message fl\">{{message.message}}</div><div class=\"name fl\">：{{message.user.name}}</div></div><div class=\"clear\"></div></li></ul><div class=\"leave-message mt-30\"><textarea v-model=\"leave_message\" placeholder=\"输入您说的话\" @keyup.enter=\"postComment\" class=\"fl\"></textarea><div class=\"btn fl ml-20\"><a @click=\"postComment\">发送留言</a></div></div></div><div slot=\"footer\"></div></modal>"
  

});
