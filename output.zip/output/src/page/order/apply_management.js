define('src/page/order/apply_management.vue', function(require, exports, module) {

  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  
  'use strict';
  
  Object.defineProperty(exports, '__esModule', {
      value: true
  });
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _srcAssetsJsPage = require('src/assets/js/page');
  
  var _srcAssetsJsConstant = require('src/assets/js/constant');
  
  var _srcAssetsJsConstant2 = _interopRequireDefault(_srcAssetsJsConstant);
  
  var _srcAssetsJsApi = require('src/assets/js/api');
  
  var _srcAssetsJsApi2 = _interopRequireDefault(_srcAssetsJsApi);
  
  var _srcPageMixins = require('src/page/mixins');
  
  var _srcPageMixins2 = _interopRequireDefault(_srcPageMixins);
  
  var _srcAssetsJsUtils = require('src/assets/js/utils');
  
  var _srcAssetsJsUtils2 = _interopRequireDefault(_srcAssetsJsUtils);
  
  var _jquery = require('node_modules/jquery/dist/jquery');
  
  var _jquery2 = _interopRequireDefault(_jquery);
  
  exports['default'] = {
      mixins: [_srcPageMixins2['default']],
      components: {
          dheader: _srcAssetsJsPage.dheader
      },
      asyncData: function asyncData(resolve) {
          this.fetch().done(function () {
              this.records = this.data;
              resolve(this);
          });
      },
      methods: {
          // 获取基本信息
          fetch: function fetch() {
              var data = this.query;
              return _srcAssetsJsApi2['default'].get({
                  url: this.url,
                  data: data
              });
          },
          toggleTab: function toggleTab(type, e) {
              _srcAssetsJsPage.Vue.set(this.query, 'status', type);
              var $el = (0, _jquery2['default'])(e.currentTarget);
              $el.addClass('active').siblings().removeClass('active');
          },
          deleteRecord: function deleteRecord(id) {
              var _this = this;
  
              _srcAssetsJsApi2['default']['delete']({
                  url: this.url + id + '/'
              }).done(function () {
                  return _this.reloadAsyncData();
              });
          }
      },
      watch: {
          query: {
              deep: true,
              handler: function handler() {
                  this.reloadAsyncData();
              }
          }
      },
      data: function data() {
          var detailURL = _srcAssetsJsConstant2['default'].PATH.ORDER_APPLY_DETAIL;
          var applyRecordURL = _srcAssetsJsConstant2['default'].PATH.ORDER_APPLY_RECORD;
  
          return {
              url: _srcAssetsJsConstant2['default'].API.APPLY_RECORDS,
              orders: [],
              records: [],
              query: {
                  status: 'active'
              },
              status: 90,
              apply_records: [],
              detailURL: detailURL,
              applyRecordURL: applyRecordURL,
              ORDER: _srcAssetsJsConstant2['default'].ORDER
          };
      }
  };
  module.exports = exports['default'];
  var __vue__options__;
  if(exports && exports.__esModule && exports.default){
    __vue__options__ = exports.default;
  }else{
    __vue__options__ = module.exports;
  }
  __vue__options__.template = "<dheader></dheader><div __vuec__4ceb8c26=\"__vuec__4ceb8c26\" class=\"pub_management\"><div class=\"banner pt-40\"><div class=\"title\">接单管理</div></div><div class=\"clear\"></div><ul class=\"tabs\"><li @click=\"toggleTab('active', $event)\" class=\"active\">订单申请记录</li><li @click=\"toggleTab('confirmed', $event)\">已确认订单</li><li @click=\"toggleTab('finished', $event)\">已完成订单</li></ul><div class=\"list-wrap\"><ul v-for=\"record in records\" class=\"orders mt-10\"><li><span class=\"title\"><a href=\"{{detailURL}}?oid={{record.order.id}}{{and}}aid={{record.id}}\">{{record.order.title}}</a></span><span class=\"pub-time ml-20\">创建于：{{record.order.pub_time | date}}</span><span class=\"system-cost\">￥{{record.order.pub_cost/100}}</span></li><li class=\"detail\"><div class=\"fl\">交付日期：{{record.order.deadline | date}}</div><div class=\"ml-60 fl\">浏览量：{{record.order.view_count}}</div><div class=\"ml-60 fl\">接单量：{{record.order.apply_count}}</div><div v-if=\"record.order.status === ORDER.CONFIRMED\" class=\"ml-60 fr count-down\">剩余时间：{{record.order.count_down}}</div><div :class=\"{special: $index === 0}\" class=\"action fr\"><div v-if=\"record.status !== 'finished'\" title=\"编辑\" class=\"edit\"><a href=\"{{applyRecordURL}}?oid={{record.order.id}}{{and}}type=edit\" target=\"_blank;\"></a></div><div @click=\"deleteRecord(record.id)\" title=\"删除\" class=\"delete\"></div></div></li></ul></div></div>"
  

});
