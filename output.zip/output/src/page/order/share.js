define('src/page/order/share.vue', function(require, exports, module) {

  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  
  'use strict';
  
  Object.defineProperty(exports, '__esModule', {
      value: true
  });
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _srcAssetsJsPage = require('src/assets/js/page');
  
  var _srcAssetsJsApi = require('src/assets/js/api');
  
  var _srcAssetsJsApi2 = _interopRequireDefault(_srcAssetsJsApi);
  
  require('jqueryui/jquery.ui');
  
  var _srcPublicUploadUpload = require('src/public/upload/upload.vue');
  
  var _srcPublicUploadUpload2 = _interopRequireDefault(_srcPublicUploadUpload);
  
  var _jquery = require('node_modules/jquery/dist/jquery');
  
  var _jquery2 = _interopRequireDefault(_jquery);
  
  var _srcAssetsJsUtils = require('src/assets/js/utils');
  
  var _srcAssetsJsUtils2 = _interopRequireDefault(_srcAssetsJsUtils);
  
  var _srcPageMixins = require('src/page/mixins');
  
  var _srcPageMixins2 = _interopRequireDefault(_srcPageMixins);
  
  _srcAssetsJsPage.Vue.filter('f2f', function (val) {
      return val ? '线上' : '线下';
  });
  _srcAssetsJsPage.Vue.filter('mesure', function (val) {
      return val ? '' : '不';
  });
  
  exports['default'] = {
      components: {
          dheader: _srcAssetsJsPage.dheader,
          upload: _srcPublicUploadUpload2['default']
      },
      asyncData: function asyncData(resolve) {
          this.fetch().done(function () {
              resolve(this.data);
          });
      },
      computed: {
          fee: function fee() {
              var fee = this.order.pub_cost - this.order.system_cost || 0;
              return fee / 100;
          }
      },
      methods: {
          // 获取发单基本信息
          fetch: function fetch() {
              return _srcAssetsJsApi2['default'].get({
                  url: this.url
              });
          }
      },
      data: function data() {
          var id = _srcAssetsJsUtils2['default'].getURLParam('id');
          var url = constant.API.ORDERS + id + constant.API.APPLY_RECORD;
          return {
              id: id,
              oid: '',
              url: url,
              user: {},
              order: {
                  dynamic_info: {}
              },
              desc: '',
              works: [],
              extra_resource: '',
              extra_resource_name: '',
              apply_cost: '',
              publicURL: constant.PATH.USER_PUB,
              demandURL: constant.PATH.ORDER_DEMAND
          };
      }
  };
  module.exports = exports['default'];
  var __vue__options__;
  if(exports && exports.__esModule && exports.default){
    __vue__options__ = exports.default;
  }else{
    __vue__options__ = module.exports;
  }
  __vue__options__.template = "<dheader></dheader><div __vuec__dcb78d2f=\"__vuec__dcb78d2f\" class=\"pub\"><div class=\"banner pt-40\"><div class=\"title\">{{order.title}}</div><div class=\"subtitle mt-10\">项目详情</div></div><div class=\"detail\"><div class=\"main container\"><div class=\"avatar mt-30\"><a href=\"{{publicURL}}?uid={{user.id}}\"><img :src=\"user.avatar\" class=\"fl\"/></a><div class=\"clear\"></div><div class=\"name\">{{user.name}}</div></div><div class=\"user-desc mt-10\">{{user.desc}}</div><div class=\"task-desc mt-30\"><span>{{order.scate}} {{order.task_count}} {{order.task_unit}}</span><span class=\"ml-30\">交稿时间剩余：{{order.count_down}}</span></div><div class=\"dynamic-desc\"><span>建筑面积 {{order.dynamic_info.area}}平米</span><span class=\"ml-30\">{{order.dynamic_info.style}}风格</span><span class=\"ml-30\">{{order.dynamic_info.is_face2face | f2f}}</span><span class=\"ml-30\">{{order.dynamic_info.is_mesure || mesure}}包括量房</span></div><div class=\"time-desc\"><span>创建时间：{{order.created_on | date 'yy-mm-dd'}}</span><span class=\"ml-30\">交稿时间：{{order.deadline | date 'yy-mm-dd'}}</span></div><ul class=\"cost-desc mt-30\"><li><span>系统报价</span><span class=\"ml-30\">￥{{order.system_cost/100 || 0}} 积分</span></li><li><span>已加赏金</span><span class=\"ml-30\">￥{{fee}} 积分</span></li></ul></div></div><div class=\"description\"><div class=\"project-desc container\"><div class=\"label border mt-20\">项目描述</div><div class=\"desc\">{{order.desc}}</div><div class=\"label border-top\">项目相关资料下载<a :href=\"order.extra_resource\" target=\"_new;\" class=\"ml-20 cyan\">{{order.extra_resource_name}}</a></div><div class=\"clear\"></div><div class=\"label cyan\">关于自由设计师接单的条例</div><textarea disabled=\"disabled\" class=\"desc\"></textarea></div></div></div>"
  

});
