define('src/page/user/account.vue', function(require, exports, module) {

  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  
  'use strict';
  
  Object.defineProperty(exports, '__esModule', {
      value: true
  });
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _srcAssetsJsPage = require('src/assets/js/page');
  
  var _srcPageUserTab = require('src/page/user/tab.vue');
  
  var _srcPageUserTab2 = _interopRequireDefault(_srcPageUserTab);
  
  var _srcPublicCutimgCutimg = require('src/public/cutimg/cutimg.vue');
  
  var _srcPublicCutimgCutimg2 = _interopRequireDefault(_srcPublicCutimgCutimg);
  
  var _srcAssetsJsUtils = require('src/assets/js/utils');
  
  var _srcAssetsJsUtils2 = _interopRequireDefault(_srcAssetsJsUtils);
  
  var _srcAssetsJsApi = require('src/assets/js/api');
  
  var _srcAssetsJsApi2 = _interopRequireDefault(_srcAssetsJsApi);
  
  var _jquery = require('node_modules/jquery/dist/jquery');
  
  var _jquery2 = _interopRequireDefault(_jquery);
  
  var _srcPublicUploadUpload = require('src/public/upload/upload.vue');
  
  var _srcPublicUploadUpload2 = _interopRequireDefault(_srcPublicUploadUpload);
  
  function without(array, val) {
      var len = array.length;
      for (var i = len - 1; i >= 0; i--) {
          var v = array[i];
          if (v === val) {
              array.splice(i, 1);
          }
      }
      return array;
  }
  
  exports['default'] = {
      components: {
          dheader: _srcAssetsJsPage.dheader,
          cutimg: _srcPublicCutimgCutimg2['default'],
          tab: _srcPageUserTab2['default'],
          upload: _srcPublicUploadUpload2['default']
      },
      asyncData: function asyncData(resolve, reject) {
          // 绑定用户信息
          window.userStat.done(function () {
              this.data.userImg = this.data.license_pic ? this.data.license_pic : './userBg.png';
              resolve(this.data);
          });
      },
      events: {
          // 上传类似作品
          uploadComplete: function uploadComplete(ret) {
              this.userImg = ret.data[0][1];
          }
      },
      methods: {
          authoriedID: function authoriedID() {
              var data = {
                  license_pic: this.userImg,
                  license_id: this.license_id
              };
              var url = '/api/users/' + this.id + '/';
              _srcAssetsJsApi2['default'].patch({
                  url: url,
                  data: data
              });
          },
          updatePasswd: function updatePasswd() {
              var url = constant.API.USER_RESETPASSWORD;
              var data = {
                  origin: this.origin,
                  new_passwd: this.newPasswd,
                  again_passwd: this.againPasswd
              };
              _srcAssetsJsApi2['default'].patch({
                  url: url,
                  data: data
              });
          },
          uploadWork: function uploadWork() {
              (0, _jquery2['default'])('#upload').click();
          }
      },
      data: function data() {
          var id = _srcAssetsJsUtils2['default'].getURLParam('id');
          var uid = _srcAssetsJsUtils2['default'].getURLParam('uid');
          return {
              // user info start
              avatar: '',
              role: '',
              name: '',
              gender: '',
              id: '',
              age: 0,
              desc: '',
              view_count: 0,
              like_count: 0,
              ids: {
                  id: id,
                  uid: uid
              },
              province: '',
              available_cash_points: '',
              city: '',
              is_recommend: '',
              available_points: '',
              audit_status: '',
              download_count: '',
              career: '',
              license_pic: '',
              mobile: '',
              apply_count: '',
              paied_points: '',
              license_id: '',
              gallery_count: '',
              remaining: '',
              userImg: ''
          };
      }
  };
  module.exports = exports['default'];
  var __vue__options__;
  if(exports && exports.__esModule && exports.default){
    __vue__options__ = exports.default;
  }else{
    __vue__options__ = module.exports;
  }
  __vue__options__.template = "<dheader></dheader><div __vuec__476180e6=\"__vuec__476180e6\" class=\"profile\"><tab></tab><div class=\"bfc detail mt-20\"><div class=\"avatar-container\"><div class=\"avatar\">?<img :src=\"avatar\"/></div></div><input v-model=\"origin\" placeholder=\"原密码\" type=\"password\" maxlength=\"12\" class=\"origin\"/><input v-model=\"newPasswd\" placeholder=\"新密码\" type=\"password\" maxlength=\"12\" class=\"mt-40\"/><div class=\"wrap mt-40\"><input v-model=\"againPasswd\" placeholder=\"再次输入新密码\" type=\"password\" maxlength=\"12\" class=\"again fl\"/><div class=\"btn fl ml-20 updatePasswd\"><a @click=\"updatePasswd\">更新密码</a></div></div><div class=\"clear\"></div><div class=\"mt-50 title\">应国家全网实名制的要求，请认证个人身份信息</div><div class=\"wrap mt-40\"><input v-model=\"license_id\" placeholder=\"请输入身份号码进行认证\" class=\"fl\"/><div class=\"clear\"></div></div><div class=\"userImg mt-4\"><p>请上传本人手持身份证照片</p><img :src=\"userImg\" @click=\"uploadWork\"/><upload type=\"work\" maxsize=\"2*1024\" class=\"upload\"></upload></div><div class=\"btn authoriedID\"><a @click=\"authoriedID\">认证</a></div></div></div>"
  

});
