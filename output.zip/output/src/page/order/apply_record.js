define('src/page/order/apply_record.vue', function(require, exports, module) {

  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  
  'use strict';
  
  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _srcAssetsJsPage = require('src/assets/js/page');
  
  var _srcAssetsJsApi = require('src/assets/js/api');
  
  var _srcAssetsJsApi2 = _interopRequireDefault(_srcAssetsJsApi);
  
  require('jqueryui/jquery.ui');
  
  var _srcPublicUploadUpload = require('src/public/upload/upload.vue');
  
  var _srcPublicUploadUpload2 = _interopRequireDefault(_srcPublicUploadUpload);
  
  var _srcPageComponentsOrderDetailOrderDetail = require('src/page/components/order-detail/order-detail.vue');
  
  var _srcPageComponentsOrderDetailOrderDetail2 = _interopRequireDefault(_srcPageComponentsOrderDetailOrderDetail);
  
  var _jquery = require('node_modules/jquery/dist/jquery');
  
  var _jquery2 = _interopRequireDefault(_jquery);
  
  var _srcAssetsJsUtils = require('src/assets/js/utils');
  
  var _srcAssetsJsUtils2 = _interopRequireDefault(_srcAssetsJsUtils);
  
  var _srcPageMixins = require('src/page/mixins');
  
  var _srcPageMixins2 = _interopRequireDefault(_srcPageMixins);
  
  _srcAssetsJsPage.Vue.filter('f2f', function (val) {
    return val ? '线上' : '线下';
  });
  _srcAssetsJsPage.Vue.filter('mesure', function (val) {
    return val ? '' : '不';
  });
  
  exports['default'] = {
    mixins: [_srcPageMixins2['default']],
    components: {
      dheader: _srcAssetsJsPage.dheader,
      upload: _srcPublicUploadUpload2['default'],
      orderdetail: _srcPageComponentsOrderDetailOrderDetail2['default']
    },
    events: {
      // 上传类似作品
      uploadComplete: function uploadComplete(ret) {
        this.works.push(ret.data[0]);
        var data = {
          works: this.works
        };
        _srcAssetsJsApi2['default'].patch({
          url: this.url + this.id + '/',
          data: data
        });
      }
    },
    asyncData: function asyncData(resolve) {
      this.fetch().done(function () {
        resolve(this.data);
      });
    },
    created: function created() {
      this.local_id = localStorage.getItem('temp_user_id');
      var getQuestionsUrl = '/api/orders/' + this.oid + '/questions/';
      var that = this;
      _srcAssetsJsApi2['default'].get({
        url: getQuestionsUrl
      }).done(function () {
        var newdata = this.data.filter(function (item, index) {
          if (item.question) {
            return item;
          }
        });
        that.questionList = newdata;
      });
      var timer = setInterval(function () {
        if (that.id) {
          (function () {
            clearInterval(timer);
            var res = [];
            var number = 0;
            for (var i = 0; i < 5; i++) {
              var getAnswerUrl = '/api/apply_records/' + that.id + '/answers';
              _srcAssetsJsApi2['default'].get({
                url: getAnswerUrl,
                data: {
                  order_question: i
                }
              }).done(function () {
                number++;
                if (this.data.length !== 0) res.push(this.data[0]);
                if (number == 5) {
                  that.res = res.length;
                  if (res.length > 0) {
                    that.answerList = res;
                    that.overAnswer = true;
                  }
                }
              });
            }
          })();
        }
      }, 1000);
    },
    computed: {
      fee: function fee() {
        var fee = this.order.pub_cost - this.order.system_cost || 0;
        return fee;
      }
    },
    methods: {
      fetch: function fetch() {
        return _srcAssetsJsApi2['default'].get({
          url: this.url
        });
      },
      submit: function submit() {
        var _this = this;
  
        var that = this;
        if (this.res > 0) {
          var data = {
            desc: that.desc,
            apply_cost: parseInt(that.apply_cost, 10),
            works: that.works
          };
          _srcAssetsJsApi2['default'].patch({
            url: that.url + that.id + '/',
            data: data
          }).done(function () {
            return window.location.href = constant.PATH.ORDER_APPLY_MANAGEMENT;
          });
        } else {
          (function () {
            var number = 0;
            for (var i = 0; i < _this.answerList.length; i++) {
              var setOrderAnswerUrl = '/api/apply_records/' + _this.id + '/answers/?order_question=' + _this.answerList[i].qid;
              var data = {
                answer: _this.answerList[i].answer,
                start_time: _this.answerList[i].start_time,
                end_time: _this.answerList[i].end_time
              };
              _srcAssetsJsApi2['default'].post({
                url: setOrderAnswerUrl,
                isNeed: true,
                data: data
              }).done(function () {
                number++;
                if (number == 5) {
                  var _data = {
                    desc: that.desc,
                    apply_cost: parseInt(that.apply_cost, 10),
                    works: that.works
                  };
                  _srcAssetsJsApi2['default'].patch({
                    url: that.url + that.id + '/',
                    data: _data
                  }).done(function () {
                    return window.location.href = constant.PATH.ORDER_APPLY_MANAGEMENT;
                  });
                }
              });
            }
          })();
        }
      },
      uploadWork: function uploadWork() {
        (0, _jquery2['default'])('#upload').click();
      },
      deleteWork: function deleteWork(index) {
        this.works.splice(index, 1);
        var works = this.works;
        _srcAssetsJsPage.Vue.set(this.works, works);
        _srcAssetsJsApi2['default'].patch({
          url: this.url + this.id + '/',
          data: {
            works: works
          }
        });
      },
      fixDesc: function fixDesc() {
        var data = {
          desc: this.desc
        };
        _srcAssetsJsApi2['default'].patch({
          url: this.url + this.id + '/',
          data: data
        });
      },
      fixCost: function fixCost() {
        var data = {
          apply_cost: parseInt(this.apply_cost, 10)
        };
        _srcAssetsJsApi2['default'].patch({
          url: this.url + this.id + '/',
          data: data
        });
      },
      beginAnswer: function beginAnswer() {
        var _this2 = this;
  
        if (this.questionList.length === 0) {
          return;
        }
        this.startTime = new Date().getTime();
        this.timer = setInterval(function () {
          _this2.timing += 1;
          var hour = Math.floor(_this2.timing / 3600);
          var min = Math.floor(_this2.timing / 60) % 60;
          var sec = _this2.timing % 60;
          var t = '';
          if (hour < 10) {
            t = '0' + hour + ':';
          } else {
            t = hour + ':';
          }
          if (min < 10) {
            t += '0';
          }
          t += min + ':';
          if (sec < 10) {
            t += '0';
          }
          t += sec;
          _this2.timingText = t;
        }, 1000);
      },
      nextQuestion: function nextQuestion() {
        this.endTime = new Date().getTime();
        var dataForm = {
          answer: this.answerContent,
          start_time: this.startTime,
          end_time: this.endTime,
          qid: this.questionList[this.nowIndex].qid
        };
        this.answerList.push(dataForm);
        this.answerContent = '';
        this.nowIndex += 1;
        this.startTime = new Date().getTime();
        if (this.nowIndex > this.questionList.length - 1) {
          this.overAnswer = true;
        }
      },
      giveUpAnswer: function giveUpAnswer() {
        clearInterval(this.timer);
        this.timer = null;
        this.timing = 0;
        this.timingText = '00:00:00';
        this.nowIndex = 0;
        this.answerContent = '';
        this.answerList = [];
      },
      showAnswerTime: function showAnswerTime(start, end) {
        var time = (end - start) / 1000;
        var hour = Math.floor(time / 3600);
        var min = Math.floor(time / 60) % 60;
        var sec = time % 60;
        var t = '';
        if (hour > 0) {
          if (hour < 10) {
            t = '0' + hour + ':';
          } else {
            t = hour + '时';
          }
        }
        if (min < 10) {
          t += '0';
        }
        t += min + '分';
        if (sec < 10) {
          t += '0';
        }
        t += sec.toFixed(0) + '秒';
        return t;
      }
    },
    data: function data() {
      var oid = _srcAssetsJsUtils2['default'].getURLParam('oid');
      var type = _srcAssetsJsUtils2['default'].getURLParam('type');
      var url = constant.API.ORDERS + oid + constant.API.APPLY_RECORD;
      return {
        local_id: '',
        id: '',
        oid: oid,
        url: url,
        user: {},
        type: type, // 当前记录是否是编辑状态
        order: {
          dynamic_info: {},
          user: {}
        },
        desc: '',
        works: [],
        extra_resource: '',
        extra_resource_name: '',
        apply_cost: '',
        publicURL: constant.PATH.USER_PUB,
        demandURL: constant.PATH.ORDER_DEMAND,
        questionList: [],
        timing: 0,
        timingText: '00:00:00',
        timer: null,
        answerContent: '',
        nowIndex: 0,
        startTime: '',
        endTime: '',
        answerList: [],
        overAnswer: false,
        showMore: false,
        res: 0,
        score: '',
        comments: ''
      };
    }
  };
  module.exports = exports['default'];
  var __vue__options__;
  if(exports && exports.__esModule && exports.default){
    __vue__options__ = exports.default;
  }else{
    __vue__options__ = module.exports;
  }
  __vue__options__.template = "<dheader></dheader><div __vuec__a9c0c33f=\"__vuec__a9c0c33f\" class=\"wrap\"><orderdetail otitle=\"项目详情\" :order=\"order\"></orderdetail><div class=\"descriptions\"><div class=\"container\"><div class=\"label\">上传同类案例（请上传jpg、png大小不超过2M的图片）</div><ul class=\"works\"><li v-for=\"work in works\"><div @click=\"deleteWork($index)\" class=\"close\">x</div><a><img :src=\"work[1]\"/></a></li><li @click=\"uploadWork\" class=\"upload\">+</li></ul><upload type=\"work\" maxsize=\"2*1024\"></upload><div class=\"label\">竞标描述</div><textarea placeholder=\"芍药居哈哈，我就在这里住哦，给我下单， 方便啊......\" v-model=\"desc\" class=\"desc\"></textarea><div @click=\"fixDesc\" class=\"fixDesc\">修改</div><div></div><div class=\"clear\"></div><div class=\"label\">问题解答</div><div @click=\"beginAnswer\" v-show=\"timing == 0 &amp;&amp; !overAnswer\" class=\"answer-btn\">开始答题</div><div v-show=\"timing &gt; 0 &amp;&amp; !overAnswer\" class=\"answering\"><div class=\"timing answer-btn\">{{ timingText }}</div><div v-for=\"(index, item) in questionList\" :key=\"index\" v-show=\"index == nowIndex\" class=\"now\"><div class=\"calc\">NO.{{ index + 1 }}/{{questionList.length}}<span>{{ item.question }}</span></div></div><textarea placeholder=\"请在此处做解答\" v-model=\"answerContent\" class=\"answerTextArea\"></textarea><div class=\"answerBtn\"><div @click=\"giveUpAnswer\" class=\"answer-btn\">放弃答题</div><div @click=\"nextQuestion\" class=\"answer-btn\">下一题</div></div></div><div v-show=\"overAnswer\" class=\"overAnswer\"><div class=\"overTittle\">【答题结束】</div><div class=\"clickMore\">试卷详情<img v-show=\"!showMore\" @click=\"showMore = true\" src=\"/src/page/order/images/open.png\" alt=\"open\" class=\"open\"/></div><div class=\"closeMore\"><img v-show=\"showMore\" @click=\"showMore = false\" src=\"/src/page/order/images/close.png\" alt=\"close\" class=\"close\"/></div><div v-show=\"showMore\" v-for=\"(index, item) in answerList\" :key=\"index\" class=\"answersBox\"><div class=\"anContent questionTop\"><div class=\"number\">第{{ index + 1 }}题</div><div>{{ questionList[index].question }}</div></div><div class=\"anContent\"><div class=\"timeAnswer\"><div class=\"time\">使用时间:【{{ showAnswerTime(item.start_time, item.end_time) }}】</div><div v-show=\"item.answer\" class=\"content\">{{ item.answer }}</div><div v-show=\"!item.answer\" class=\"noAnswer\">接单人没有回答此试题</div></div></div></div></div><div class=\"label\">我想加价</div><div class=\"wrap\"><input v-model=\"apply_cost\" type=\"number\"/><div @click=\"fixCost\" class=\"fixCost\">确认</div><span></span></div><div class=\"action mt-30\"><div class=\"btn fl btn-gray w-100\"><a :href=\"demandURL\">返回需求池</a></div><div v-if=\"local_id != order.user.id\" class=\"btn fl ml-30\"><a v-if=\"!type\" @click=\"submit\">确认接单</a><a @click=\"submit\">保存接单</a></div></div></div></div></div>"
  

});
