define('src/page/order/order_user_info.vue', function(require, exports, module) {

  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  
  'use strict';
  
  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _srcAssetsJsApi = require('src/assets/js/api');
  
  var _srcAssetsJsApi2 = _interopRequireDefault(_srcAssetsJsApi);
  
  var _srcAssetsJsUtils = require('src/assets/js/utils');
  
  var _srcAssetsJsUtils2 = _interopRequireDefault(_srcAssetsJsUtils);
  
  var _srcAssetsJsEventVue = require('src/assets/js/eventVue');
  
  var _srcAssetsJsEventVue2 = _interopRequireDefault(_srcAssetsJsEventVue);
  
  exports['default'] = {
    props: ['info', 'detail'],
    asyncData: function asyncData(resolve) {
      var _this = this;
  
      var self = this;
      setTimeout(function () {
        var n = 0;
        var res = [];
        for (var i = 0; i < 5; i++) {
          _srcAssetsJsApi2['default'].get({
            url: '/api/apply_records/' + _this.info.id + '/answers/',
            data: {
              order_question: i
            }
          }).done(function () {
            n++;
            if (this.data.length !== 0) res.push(this.data[0]);
            if (n === 5) {
              resolve(Object.assign({}, {
                userQuestionList: res
              }));
            }
          });
        }
      }, 1000);
    },
    filters: {
      filterRole: function filterRole(val) {
        if (!val) return '';
        return val.split(',').filter(function (v) {
          return v !== '';
        }).map(function (v) {
          return '【' + v + '】';
        }).join('');
      }
    },
    methods: {
      close: function close() {
        this.$emit('closeuserinfo');
      },
      showAnswerTime: function showAnswerTime(start, end) {
        var time = (end - start) / 1000;
        var hour = Math.floor(time / 3600);
        var min = Math.floor(time / 60) % 60;
        var sec = time % 60;
        var t = '';
        if (hour > 0) {
          if (hour < 10) {
            t = '0' + hour + ':';
          } else {
            t = hour + '时';
          }
        }
        if (min < 10) {
          t += '0';
        }
        t += min + '分';
        if (sec < 10) {
          t += '0';
        }
        t += sec.toFixed(0) + '秒';
        return t;
      },
      surePay: function surePay() {
        _srcAssetsJsApi2['default'].post({
          url: '/api/pay/create_order/',
          data: {
            goods_id: this.info.id,
            goods_type: 'pre_order',
            price_type: 'all'
          }
        }).done(function () {
          window.location.reload();
        });
      }
    }
  };
  module.exports = exports['default'];
  var __vue__options__;
  if(exports && exports.__esModule && exports.default){
    __vue__options__ = exports.default;
  }else{
    __vue__options__ = module.exports;
  }
  __vue__options__.template = "\n  <div class=\"containers\" __vuec__d99334fc>\n    <div class=\"mains\">\n    <div class=\"close\" @click=\"close\">X</div>\n\n      <div class=\"main-header\">\n        <div class=\"user-info\">\n          <div class=\"avatarssss\">\n            <img :src=\"info.user.avatar\" alt=\"\">\n          </div>\n          <div class=\"info\">\n            <div class=\"item-header\">\n              <div class=\"title\">{{info.user.name}}</div>\n            </div>\n            <div>\n              <div class=\"exp\">{{info.user.career}}年工作经验</div>\n            </div>\n            <div class=\"skill\">\n              {{info.user.role}}\n            </div>\n            <div class=\"integral\">议价：{{info.apply_cost / 100}}积分</div>\n          </div>\n        </div>\n        <div class=\"explain\">\n          <h3>竞标说明</h3>\n          <p>{{info.desc || '暂无'}}</p>\n        </div>\n      </div>\n      <div class=\"test-paper\">\n        <div class=\"paper-header\">\n          <h3>答题试卷<span>【您设置了{{userQuestionList.length}}道试题】</span></h3>\n        </div>\n        <div class=\"paper-main\">\n          <div class=\"item\" v-for=\"item in userQuestionList\">\n            <div class=\"headerrrrrrrr\">\n              <h4>第{{ $index + 1 }}题：{{ item.order_question.question }}</h4>\n              <div class=\"time\">\n                <img src=\"./ico_time.png\" alt=\"\">【{{ showAnswerTime(item.start_time, item.end_time) }}】\n              </div>\n            </div>\n            <p>{{ item.answer }}</p>\n          </div>\n        </div>\n        <!-- 117338可用积分 -->\n      </div>\n      <div class=\"tel-check\">\n        <h3>电话考核</h3>\n        <a :href=\"`tel:${info.user.mobile}`\"><img src=\"/src/page/order/images/ico_tel.png\" alt=\"\"></a>\n        <p>{{info.user.mobile}}</p>\n      </div>\n      <div class=\"footersss\">\n        <h4 class=\"total-price\">服务总价：{{(detail.pub_cost + info.apply_cost) / 100}}积分</h4>\n        <div class=\"price-info\">【系统报价{{detail.system_cost}}+增加奖金{{detail.fee / 100}}+接单人加价{{info.apply_cost / 100}}】</div>\n        <div class=\"submit\" @click=\"surePay\">确定合作并付款</div>\n        <div class=\"agree\" @click=\"showAgree\">\n          <img src=\"/src/page/order/images/redyes.png\" alt=\"redyes\">\n          <span>我已阅读并同意遵守本次服务协议</span>\n        </div>\n      </div>\n    </div>\n</div>\n"
  

});
