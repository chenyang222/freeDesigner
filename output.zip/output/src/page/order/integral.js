define('src/page/order/integral.vue', function(require, exports, module) {

  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  
  'use strict';
  
  Object.defineProperty(exports, '__esModule', {
      value: true
  });
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _srcAssetsJsPage = require('src/assets/js/page');
  
  var _srcAssetsJsApi = require('src/assets/js/api');
  
  var _srcAssetsJsApi2 = _interopRequireDefault(_srcAssetsJsApi);
  
  var _srcPageMixins = require('src/page/mixins');
  
  var _srcPageMixins2 = _interopRequireDefault(_srcPageMixins);
  
  var _jquery = require('node_modules/jquery/dist/jquery');
  
  var _jquery2 = _interopRequireDefault(_jquery);
  
  var serIntervalSuccess;
  exports['default'] = {
      name: "integral",
      mixins: [_srcPageMixins2['default']],
      components: {
          dheader: _srcAssetsJsPage.dheader
      },
      created: function created() {
          this.get_add_prestore();
      },
      asyncData: function asyncData(resolve) {
          this.get_add_prestore().done(function () {
              this.list = this.data;
              resolve(this);
          });
      },
  
      methods: {
          get_add_prestore: function get_add_prestore() {
              var vm = this;
              return _srcAssetsJsApi2['default'].get({
                  url: vm.url
              });
          },
          prestore_info: function prestore_info(index, id) {
              this.active_index = index;
              this.designerID = id;
          },
          pay: function pay() {
              var vm = this;
  
              if (vm.designerID == '') {
                  alert('请选择购买积分');
              } else {
                  var r = confirm("确认支付?");
                  if (r == true) {
                      _srcAssetsJsApi2['default'].post({
                          url: constant.API.PAY_CREATE_ORDER,
                          data: {
                              goods_id: this.designerID,
                              goods_type: 'prestore',
                              price_type: 'prestore',
                              pay_type: 1,
                              pay_from: 'pc'
                          }
                      }).done(function () {
                          vm.orderUrl = this.data.url;
                          vm.orderId = this.data.id;
                          vm.isIframe = true;
                          vm.isShow = true;
                          vm.isSuccessShow = false;
                          serIntervalSuccess = setInterval(function () {
                              vm.getSuccess();
                          }, 3000);
                      });
                  }
              }
          },
          getSuccess: function getSuccess() {
              var vm = this;
  
              _srcAssetsJsApi2['default'].get({
                  url: constant.API.PAY_CHECK,
                  data: {
                      order_id: vm.orderId
                  }
              }).done(function () {
                  if (this.data.is_paied == true) {
                      clearInterval(serIntervalSuccess);
                      vm.isIframe = false;
                      vm.isShow = true;
                      vm.isSuccessShow = true;
                      // vm.$router.push({ path: '/mySuccess' })
                  }
              });
          },
          backThisPage: function backThisPage() {
              var vm = this;
              vm.isShow = false;
              vm.isSuccessShow = false;
          }
      },
      data: function data() {
          return {
              url: constant.API.GET_ADD_PRESTORE,
              list: '',
              active_index: '',
              designerID: '',
              isShow: false,
              orderUrl: '',
              orderId: '',
              isIframe: false,
              isSuccessShow: false
          };
      }
  };
  module.exports = exports['default'];
  var __vue__options__;
  if(exports && exports.__esModule && exports.default){
    __vue__options__ = exports.default;
  }else{
    __vue__options__ = module.exports;
  }
  __vue__options__.template = "\n<div class=\"integral\" __vuec__a00c0aa3>\n    <dheader></dheader>\n    <div class=\"container\">\n        <form class=\"cont layui-form\"><h2 class=\"title\">第一步：选择溜币充值套包</h2>\n            <ul class=\"package row clearfix\">\n                <li v-for=\"(index,item) in list\" @click=\"prestore_info(index,item.id)\">\n                    <label :class=\"{active:active_index === index}\">\n                        <dl>\n                            <dt>\n                                <h3><span>{{item.total_points}}积分</span></h3>\n                                <p>积分:{{item.ori_points}} 赠送:{{item.extra_points}} </p>\n                                <span class=\"\"> &nbsp; {{item.name}} </span>\n                            </dt>\n                            <dd>\n                                <p><span class=\"package_price js\">{{item.order_cost}}元</span></p>\n                            </dd>\n                        </dl>\n                        <span class=\"iconfont\"><i>✓</i></span>\n                    </label>\n                </li>\n            </ul>\n            <!--<h2 class=\"title\">第二步：选择优惠信息</h2>-->\n            <!--<div class=\"discount\">-->\n            <!--<div class=\"layui-inline\">-->\n            <!--<div class=\"layui-input-inline\"><select lay-ignore=\"\" id=\"changeCoupon\">-->\n            <!--<option value=\"\">选择优惠信息</option>-->\n            <!--<option value=\"\">暂无优惠券可使用</option>-->\n            <!--</select></div>-->\n            <!--</div>-->\n            <!--</div>-->\n            <h2 class=\"title\">第二步：选择支付方式并付款</h2>\n            <div class=\"payway clearfix\">\n                <label class=\"wechatpay\" data-payway=\"0\">\n                    <i class=\"iconfont\"></i>\n                </label>\n            </div>\n            <div class=\"payway clearfix\">\n                <button type=\"button\" id=\"goToPayBt\" class=\"click-botton\" @click=\"pay\">立即支付</button>\n            </div>\n        </form>\n\n        <div class=\"wrap-info\" v-show=\"isShow== true\">\n            <div class=\"wrap-info-block\" v-show=\"isSuccessShow\">\n                <div><img src=\"/src/page/order/images/yes.png\"/></div>\n                <div class=\"wrap-txt\">\n                    <span>购买：{{list[active_index].ori_points}}</span>&nbsp;&nbsp;\n                    <span>赠送：{{list[active_index].extra_points}}</span>\n                    <span>支付：{{list[active_index].order_cost}}</span>\n                </div>\n                <div class=\"\">\n                    <a class=\"btn\" href=\"/\">返回首页</a>\n                    <span class=\"btn\" style=\"background-color: #fa7d3e\" @click=\"backThisPage\">继续购买</span>\n                </div>\n            </div>\n            <div class=\"pay-code\" v-if=\"isIframe\">\n                <div><img :src=\"orderUrl\" class=\"code-img\" /></div>\n                <div class=\"loading\"><img src=\"/src/page/order/images/loading.gif\">支付中...</div>\n            </div>\n        </div>\n\n    </div>\n</div>\n"
  

});
