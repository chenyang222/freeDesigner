define('src/page/components/banner/index.vue', function(require, exports, module) {

  //
  //
  //
  //
  //
  //
  //
  //
  //
  
  'use strict';
  
  Object.defineProperty(exports, '__esModule', {
      value: true
  });
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _assetsJsEventVue = require('src/assets/js/eventVue');
  
  var _assetsJsEventVue2 = _interopRequireDefault(_assetsJsEventVue);
  
  var _srcAssetsJsApi = require('src/assets/js/api');
  
  var _srcAssetsJsApi2 = _interopRequireDefault(_srcAssetsJsApi);
  
  var _srcAssetsJsConstant = require('src/assets/js/constant');
  
  var _srcAssetsJsConstant2 = _interopRequireDefault(_srcAssetsJsConstant);
  
  var _lodash = require('node_modules/lodash/lodash');
  
  var _lodash2 = _interopRequireDefault(_lodash);
  
  exports['default'] = {
      // 获取users的信息
      asyncData: function asyncData(resolve) {
          this.fetch().done(function () {
              resolve(this);
          });
      },
      computed: {
          isLogout: function isLogout() {
              return this.data && JSON.stringify(this.data) === '{}';
          }
      },
      methods: {
          fetch: function fetch() {
              var promise = _srcAssetsJsApi2['default'].get({
                  url: _srcAssetsJsConstant2['default'].API.USER_STAT
              });
              return promise;
          }
      },
      data: function data() {
          return _lodash2['default'].merge({}, _srcAssetsJsConstant2['default'].PATH, {
              info: {},
              data: {},
              // 未登录状态
              success: false,
              REGISTER: _srcAssetsJsConstant2['default'].PATH.REGISTER
          });
      }
  };
  module.exports = exports['default'];
  var __vue__options__;
  if(exports && exports.__esModule && exports.default){
    __vue__options__ = exports.default;
  }else{
    __vue__options__ = module.exports;
  }
  __vue__options__.template = "\n<div class=\"banner\" __vuec__d2eb1610>\n  <img src=\"/src/page/components/banner/banner.png\" alt=\"banner\">\n  <div v-if=\"!data.id\" class=\"info\">\n    <p>现在就与  28593  万名工程师成为挚友 </p>\n    <a :href=\"REGISTER\">加入我们</a>\n  </div>\n</div>\n"
  

});
