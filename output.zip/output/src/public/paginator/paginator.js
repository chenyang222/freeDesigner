define('src/public/paginator/paginator.vue', function(require, exports, module) {

  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  
  'use strict';
  
  Object.defineProperty(exports, '__esModule', {
      value: true
  });
  exports['default'] = {
      // info parameters [total_count, per_page, page]
      props: ['info', 'size'],
      created: function created() {
          if (!this.info) {
              this.info = {
                  page: 1
              };
          }
      },
      computed: {
          // 分页组的数目
          showCountNumber: function showCountNumber() {
              return Math.ceil(this.count / this.maxsize);
          },
          // 分页组的起始页
          startCount: function startCount() {
              if (!this.countNumber) return;
              var number = this.countNumber - 1;
              var count = number * this.maxsize + 1;
              return count;
          },
          // 分页组的结束页
          endCount: function endCount() {
              if (!this.countNumber) return;
              var count = this.countNumber * this.maxsize;
              count = count > this.count ? this.count : count;
              return count;
          },
          // 分页组循环的数组
          loopCount: function loopCount() {
              if (!this.startCount && !this.endCount) return;
              var list = [];
              for (var i = this.startCount; i <= this.endCount; i++) {
                  list.push(i);
              }
              return list;
          },
          // 是否显示前省略
          showPreEllipsis: function showPreEllipsis() {
              // 当前页大于显示的页数
              return this.page > this.maxsize;
          },
          // 是否显示后省略
          showNextEllipsis: function showNextEllipsis() {
              // 当前页不在最后一页
              return this.endCount < this.count;
          },
          // 是否是第一页
          isFirst: function isFirst() {
              return this.page === 1;
          },
          // 是否是最后一页
          isLast: function isLast() {
              return this.page >= this.count;
          }
      },
      watch: {
          page: function page(val, oldVal) {
              this.dispatchChangePageEvent();
          },
          info: function info(_info) {
              if (!_info) return;
              var page = parseInt(_info.page, 10);
              var totalCount = _info.total_count;
              var perPage = _info.per_page;
              // count is 当前分页的数目
              var count = Math.ceil(totalCount / perPage);
              var number = Math.ceil(this.page / this.maxsize);
              this.page = page;
              this.countNumber = number;
              this.count = count;
          }
      },
      methods: {
          // 重新fetch当前页面数据
          dispatchChangePageEvent: function dispatchChangePageEvent() {
              this.$parent.changePage(this.page);
          },
          // 到第一页
          prevAll: function prevAll() {
              if (this.page === 1) {
                  return;
              }
              this.countNumber = 1;
              this.page = 1;
          },
          // 上一页
          prevOne: function prevOne(e) {
              if (this.page !== 1) {
                  var page = --this.page;
                  this.page = page;
                  // 假如上一页到了上一个分组
                  if (page < this.startCount) {
                      this.countNumber--;
                  }
                  return;
              }
          },
          // 跳到上一个分页组
          prevCountNumber: function prevCountNumber() {
              if (this.countNumber > 1) {
                  this.countNumber--;
                  var page = this.page - this.maxsize;
                  this.page = page < 1 ? 1 : page;
              }
          },
          // 跳到下一个分页组
          nextCountNumber: function nextCountNumber() {
              if (this.countNumber < this.showCountNumber) {
                  this.countNumber++;
                  var page = this.page + this.maxsize;
                  this.page = page > this.count ? this.count : page;
              }
          },
          // 下一页
          nextOne: function nextOne(e) {
              if (this.page < this.count) {
                  var page = ++this.page;
                  this.page = page;
                  // 假如下一页到了下一个分组
                  if (page > this.endCount) {
                      this.countNumber++;
                  }
                  return;
              }
          },
          // 最后一页
          nextAll: function nextAll() {
              if (this.page >= this.count) {
                  return;
              }
              this.countNumber = this.showCountNumber;
              this.page = this.count;
          }
      },
      data: function data() {
          var maxsize = this.size || 8;
          return {
              countNumber: 0,
              page: 1,
              maxsize: maxsize,
              count: 0
          };
      }
  };
  module.exports = exports['default'];
  var __vue__options__;
  if(exports && exports.__esModule && exports.default){
    __vue__options__ = exports.default;
  }else{
    __vue__options__ = module.exports;
  }
  __vue__options__.template = "<div __vuec__18bedd41=\"__vuec__18bedd41\" v-if=\"count &gt; 1\" class=\"wrap\"><div class=\"paginator container\"><ul><li @click=\"prevAll\" :class=\"{disabled: isFirst}\" class=\"prevAll\"><a>首页</a></li><li @click=\"prevOne | debounce 150\" :class=\"{disabled: isFirst}\" class=\"prevOne ml-10\"><a>上一页</a></li><li v-show=\"showPreEllipsis\" @click=\"prevCountNumber\" class=\"preEllipsis ml-10\"><a>...</a></li><li v-for=\"(index, item) in loopCount\" :class=\"{active: this.page === item}\" class=\"ml-10\"><a @click=\"this.page = item\">{{item}}</a></li><li v-show=\"showNextEllipsis\" @click=\"nextCountNumber\" class=\"nextEllipsis ml-10\"><a>...</a></li><li @click=\"nextOne | debounce 150\" :class=\"{disabled: isLast}\" class=\"nextOne ml-10\"><a>下一页</a></li><li @click=\"nextAll\" :class=\"{disabled: isLast}\" class=\"nextAll ml-10\"><a>尾页</a></li></ul></div></div>"
  

});
