define('src/public/radar/radar.vue', function(require, exports, module) {

  //
  //
  //
  //
  
  'use strict';
  
  Object.defineProperty(exports, '__esModule', {
      value: true
  });
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _echartsLibEcharts = require('node_modules/echarts/lib/echarts');
  
  var _echartsLibEcharts2 = _interopRequireDefault(_echartsLibEcharts);
  
  require('node_modules/echarts/lib/chart/radar');
  
  require('node_modules/echarts/lib/component/tooltip');
  
  require('node_modules/echarts/lib/component/title');
  
  var _srcAssetsJsUtils = require('src/assets/js/utils');
  
  var _srcAssetsJsUtils2 = _interopRequireDefault(_srcAssetsJsUtils);
  
  var _srcAssetsJsApi = require('src/assets/js/api');
  
  var _srcAssetsJsApi2 = _interopRequireDefault(_srcAssetsJsApi);
  
  exports['default'] = {
      asyncData: function asyncData(resolve, reject) {
          var self = this;
          this.fetch().done(function () {
              self.transData(this);
              resolve(this);
          });
      },
      methods: {
          // 获取当前用户的能力模型
          fetch: function fetch() {
              var uid = _srcAssetsJsUtils2['default'].getURLParam("uid");
              return _srcAssetsJsApi2['default'].get({
                  url: constant.API.USER_ABILITY + uid + "/"
              });
          },
          transData: function transData(respData) {
              var indicator = [];
              var values = [];
              var info = respData.info || {};
              Object.keys(respData.data).forEach(function (text) {
                  indicator.push({
                      text: text,
                      max: info.max || 0
                  });
                  var value = respData.data[text];
                  values.push(value);
              });
              if (values.length) {
                  this.option.radar.indicator = indicator;
                  this.option.series[0].data[0].value = values;
              }
          },
          renderChart: function renderChart() {
              this.$chart && this.$chart.setOption(this.option);
          }
      },
      watch: {
          option: {
              deep: true,
              handler: function handler() {
                  this.renderChart();
              }
          }
      },
      ready: function ready() {
          var $radar = document.getElementById('radar');
          var $chart = $radar.getElementsByClassName('chart');
          this.$chart = _echartsLibEcharts2['default'].init($chart[0]);
      },
      data: function data() {
          return {
              $chart: {},
              info: {},
              data: {},
              success: false,
              option: {
                  title: {
                      text: '能力雷达图',
                      textStyle: {
                          color: '#fff'
                      }
                  },
                  tooltip: {
                      trigger: 'item',
                      position: 'inside',
                      textStyle: {
                          fontSize: 10
                      }
                  },
                  radar: {
                      indicator: [],
                      center: ['50%', '50%'],
                      radius: '75%',
                      startAngle: 50,
                      splitNumber: 5,
                      shape: 'circle',
                      name: {
                          formatter: '{value}',
                          textStyle: {
                              color: '#fff'
                          }
                      },
                      splitArea: {
                          areaStyle: {
                              color: '#666',
                              shadowBlur: 10
                          }
                      },
                      axisLine: {
                          lineStyle: {
                              color: 'rgba(255, 255, 255, 0.5)'
                          }
                      },
                      splitLine: {
                          lineStyle: {
                              color: 'rgba(255, 255, 255, 0.5)'
                          }
                      }
                  },
                  series: [{
                      name: '雷达图',
                      type: 'radar',
                      tooltip: {
                          trigger: 'item'
                      },
                      label: {
                          normal: {
                              // show: true,
                              textStyle: {
                                  color: '#fff'
                              }
                          }
                      },
                      itemStyle: {
                          normal: {
                              areaStyle: {
                                  color: new _echartsLibEcharts2['default'].graphic.RadialGradient(0.5, 0.5, 0.5, [{
                                      offset: 0,
                                      color: 'blue'
                                  }, {
                                      offset: 0.7,
                                      color: 'red'
                                  }, {
                                      offset: 1,
                                      color: 'yellow'
                                  }], false)
                              }
                          }
                      },
                      data: [{
                          // 数据部分
                          value: [],
                          // 每个数据点
                          symbol: 'circle',
                          symbolSize: 10,
                          itemStyle: {
                              normal: {
                                  color: 'yellow'
                              }
                          },
                          lineStyle: {
                              normal: {
                                  color: 'yellow'
                              }
                          }
                      }]
                  }]
              }
          };
      }
  };
  module.exports = exports['default'];
  var __vue__options__;
  if(exports && exports.__esModule && exports.default){
    __vue__options__ = exports.default;
  }else{
    __vue__options__ = module.exports;
  }
  __vue__options__.template = "<div id=\"radar\"><div class=\"chart\"></div></div>"
  

});
