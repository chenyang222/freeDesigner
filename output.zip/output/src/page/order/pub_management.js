define('src/page/order/pub_management.vue', function(require, exports, module) {

  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  
  'use strict';
  
  Object.defineProperty(exports, '__esModule', {
      value: true
  });
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _srcAssetsJsPage = require('src/assets/js/page');
  
  var _srcAssetsJsApi = require('src/assets/js/api');
  
  var _srcAssetsJsApi2 = _interopRequireDefault(_srcAssetsJsApi);
  
  var _srcPageMixins = require('src/page/mixins');
  
  var _srcPageMixins2 = _interopRequireDefault(_srcPageMixins);
  
  var _srcAssetsJsUtils = require('src/assets/js/utils');
  
  var _srcAssetsJsUtils2 = _interopRequireDefault(_srcAssetsJsUtils);
  
  var _jquery = require('node_modules/jquery/dist/jquery');
  
  var _jquery2 = _interopRequireDefault(_jquery);
  
  exports['default'] = {
      mixins: [_srcPageMixins2['default']],
      components: {
          dheader: _srcAssetsJsPage.dheader
      },
      asyncData: function asyncData(resolve) {
          this.fetch().done(function () {
              this.orders = this.data;
              resolve(this);
          });
      },
      methods: {
          // 获取基本信息
          fetch: function fetch() {
              var data = this.query;
              return _srcAssetsJsApi2['default'].get({
                  url: this.url,
                  data: data
              });
          },
          // toggleTab(type, e) {
          //     switch(type) {
          //         case 'unconfirmed':
          //             Vue.delete(this.query, 'status');
          //             Vue.delete(this.query, 'status__lte');
          //             Vue.set(this.query, 'status__gt', 80);
          //         break;
          //         case 'confirmed':
          //             Vue.set(this.query, 'status__lte', 80);
          //             Vue.set(this.query, 'status__gt', 0);
          //         break;
          //         case 'done':
          //             Vue.delete(this.query, 'status__gt');
          //             Vue.delete(this.query, 'status__lte');
          //             Vue.set(this.query, 'status', 0);
          //         break;
          //     }
          //     let $el = $(e.currentTarget);
          //     $el.addClass('active')
          //       .siblings()
          //       .removeClass('active');
          // },
          toggleTab: function toggleTab(type) {
              switch (type) {
                  case 'unconfirmed':
                      _srcAssetsJsPage.Vue['delete'](this.query, 'status');
                      _srcAssetsJsPage.Vue['delete'](this.query, 'status__lte');
                      _srcAssetsJsPage.Vue.set(this.query, 'status__gt', 80);
                      break;
                  case 'confirmed':
                      _srcAssetsJsPage.Vue.set(this.query, 'status__lte', 80);
                      _srcAssetsJsPage.Vue.set(this.query, 'status__gt', 0);
                      break;
                  case 'done':
                      _srcAssetsJsPage.Vue['delete'](this.query, 'status__gt');
                      _srcAssetsJsPage.Vue['delete'](this.query, 'status__lte');
                      _srcAssetsJsPage.Vue.set(this.query, 'status', 0);
                      break;
              }
              this.active_tab = type;
          },
          deleteOrder: function deleteOrder(id) {
              var _this = this;
  
              _srcAssetsJsApi2['default']['delete']({
                  url: this.url + id + '/'
              }).done(function () {
                  return _this.reloadAsyncData();
              });
          }
      },
      watch: {
          query: {
              deep: true,
              handler: function handler() {
                  this.reloadAsyncData();
              }
          }
      },
      created: function created() {
          var href = location.search.split('=')[1];
          console.log(href);
          if (href == 'confirmed') {
              this.active_tab = href;
              this.toggleTab(this.active_tab);
          }
      },
      data: function data() {
          var pubOrderURL = constant.PATH.ORDER_PUB;
          var shareURL = constant.PATH.ORDER_SHARE;
          var detailURL = constant.PATH.ORDER_DETAIL;
  
          return {
              active_tab: 'unconfirmed',
              url: constant.API.ORDERS,
              orders: [],
              query: {
                  status__gt: 80
              },
              status: 90,
              apply_records: [],
              pubOrderURL: pubOrderURL,
              shareURL: shareURL,
              detailURL: detailURL
          };
      }
  };
  module.exports = exports['default'];
  var __vue__options__;
  if(exports && exports.__esModule && exports.default){
    __vue__options__ = exports.default;
  }else{
    __vue__options__ = module.exports;
  }
  __vue__options__.template = "<dheader></dheader><div __vuec__6381fac5=\"__vuec__6381fac5\" class=\"pub_management\"><div class=\"banner pt-40\"><div class=\"title\">发单管理<div class=\"btn create-order ml-20\"><a href=\"{{pubOrderURL}}\" target=\"_blank;\">新建发单</a></div></div></div><div class=\"clear\"></div><ul class=\"tabs\"><li :class=\"[active_tab == 'unconfirmed' ? 'active': '']\" @click=\"toggleTab('unconfirmed')\">未确认订单</li><li :class=\"[active_tab == 'confirmed' ? 'active': '']\" @click=\"toggleTab('confirmed')\">已确认订单</li><li :class=\"[active_tab == 'done' ? 'active': '']\" @click=\"toggleTab('done')\">已完成订单</li></ul><div class=\"list-wrap\"><ul v-for=\"order in orders\" class=\"orders mt-10\"><li><span class=\"title\"><a href=\"{{detailURL}}?id={{order.id}}\">{{order.title}}</a></span><span class=\"pub-time ml-20\">创建于：{{order.pub_time | date}}</span><span class=\"system-cost\">￥{{order.pub_cost/100}}</span></li><li class=\"detail\"><div class=\"fl\">交付日期：{{order.deadline | date}}</div><div class=\"ml-60 fl\">浏览量：{{order.view_count}}</div><div class=\"ml-60 fl\">接单量：{{order.apply_count}}</div><div v-if=\"order.status === 80\" class=\"ml-60 fr count-down\">剩余时间：{{order.count_down}}</div><div v-if=\"order.status !== 80\" :class=\"{special: $index === 0}\" class=\"action fr\"><div title=\"分享订单\" class=\"share\"><a href=\"{{shareURL}}?id={{order.id}}\" target=\"_blank;\"></a></div><div v-if=\"order.status !== 0\" title=\"编辑订单\" class=\"edit\"><a href=\"{{pubOrderURL}}?id={{order.id}}\" target=\"_blank;\"></a></div><div v-if=\"order.status !== 0\" @click=\"deleteOrder(order.id)\" title=\"删除订单\" class=\"delete\"></div></div></li></ul></div></div>"
  

});
