define('src/page/components/banner/index.vue', function(require, exports, module) {

  //
  //
  //
  //
  //
  //
  //
  //
  //
  
  'use strict';
  
  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _srcAssetsJsConstant = require('src/assets/js/constant');
  
  var _srcAssetsJsConstant2 = _interopRequireDefault(_srcAssetsJsConstant);
  
  exports['default'] = {
    data: function data() {
      return {
        REGISTER: _srcAssetsJsConstant2['default'].PATH.REGISTER
      };
    }
  };
  module.exports = exports['default'];
  var __vue__options__;
  if(exports && exports.__esModule && exports.default){
    __vue__options__ = exports.default;
  }else{
    __vue__options__ = module.exports;
  }
  __vue__options__.template = "\n<div class=\"banner\" __vuec__d2eb1610>\n  <img src=\"/src/page/components/banner/banner.png\" alt=\"banner\">\n  <div class=\"info\">\n    <p>现在就与  28593  万名工程师成为挚友 </p>\n    <a :href=\"REGISTER\">加入我们</a>\n  </div>\n</div>\n"
  

});
