define('src/assets/js/page', function(require, exports, module) {

  /**
      @file: 页面基本脚本
      @date: 2016.06.30 04:24 PM
      @author: lisen04@baidu.com
  */
  
  'use strict';
  
  Object.defineProperty(exports, '__esModule', {
      value: true
  });
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _vue = require('node_modules/vue/dist/vue.common');
  
  var _vue2 = _interopRequireDefault(_vue);
  
  var _srcPageComponentsHeaderHeaderVue = require('src/page/components/header/header.vue');
  
  var _srcPageComponentsHeaderHeaderVue2 = _interopRequireDefault(_srcPageComponentsHeaderHeaderVue);
  
  var _srcPageComponentsFooterFooterVue = require('src/page/components/footer/footer.vue');
  
  var _srcPageComponentsFooterFooterVue2 = _interopRequireDefault(_srcPageComponentsFooterFooterVue);
  
  var _vueAsyncData = require('node_modules/vue-async-data/vue-async-data');
  
  var _vueAsyncData2 = _interopRequireDefault(_vueAsyncData);
  
  // 开启debugger模式
  _vue2['default'].config.debug = true;
  
  _vue2['default'].use(_vueAsyncData2['default']);
  
  // 加载公共Filters
  _vue2['default'].filter('date', require('util/filters/dateFormat'));
  _vue2['default'].filter('encode', function (str) {
      return encodeURIComponent(str);
  });
  _vue2['default'].filter('decode', function (str) {
      return decodeURIComponent(str);
  });
  
  exports['default'] = {
      Vue: _vue2['default'],
      dheader: _srcPageComponentsHeaderHeaderVue2['default'],
      dfooter: _srcPageComponentsFooterFooterVue2['default']
  };
  module.exports = exports['default'];

});
