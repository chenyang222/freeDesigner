define('src/page/user/space.vue', function(require, exports, module) {

  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  
  'use strict';
  
  Object.defineProperty(exports, '__esModule', {
      value: true
  });
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _srcPublicUploadUpload = require('src/public/upload/upload.vue');
  
  var _srcPublicUploadUpload2 = _interopRequireDefault(_srcPublicUploadUpload);
  
  var _srcAssetsJsPage = require('src/assets/js/page');
  
  var _srcPageUserTab = require('src/page/user/tab.vue');
  
  var _srcPageUserTab2 = _interopRequireDefault(_srcPageUserTab);
  
  var _srcAssetsJsUtils = require('src/assets/js/utils');
  
  var _srcAssetsJsUtils2 = _interopRequireDefault(_srcAssetsJsUtils);
  
  var _srcAssetsJsApi = require('src/assets/js/api');
  
  var _srcAssetsJsApi2 = _interopRequireDefault(_srcAssetsJsApi);
  
  var _srcPageComponentsUserGalleryGallery = require('src/page/components/user-gallery/gallery.vue');
  
  var _srcPageComponentsUserGalleryGallery2 = _interopRequireDefault(_srcPageComponentsUserGalleryGallery);
  
  var _srcPublicModalModal = require('src/public/modal/modal.vue');
  
  var _srcPublicModalModal2 = _interopRequireDefault(_srcPublicModalModal);
  
  var _jquery = require('node_modules/jquery/dist/jquery');
  
  var _jquery2 = _interopRequireDefault(_jquery);
  
  exports['default'] = {
      components: {
          dheader: _srcAssetsJsPage.dheader,
          gallery: _srcPageComponentsUserGalleryGallery2['default'],
          modal: _srcPublicModalModal2['default'],
          tab: _srcPageUserTab2['default'],
          upload: _srcPublicUploadUpload2['default']
      },
      asyncData: function asyncData(resolve, reject) {
          // 绑定用户信息
          window.userStat.done(function () {
              resolve(this.data);
          });
      },
      events: {
          // 获取分类
          getCates: function getCates(scates) {
              this.scates = scates;
          },
          // 编辑相册
          editGallery: function editGallery(gallery) {
              this.type = 'patch';
              this.gname = gallery.name;
              this.scate = gallery.scate;
              this.gdesc = gallery.desc;
              this.showModal = true;
              this.download_url = gallery.download_url;
              this.concept = gallery.concept;
              this.gid = gallery.id;
              this.fname = gallery.fname;
          },
          uploadComplete: function uploadComplete(ret) {
              this.download_url = ret.data[0][1];
              this.fname = ret.fname;
          }
      },
      methods: {
          uploadWork: function uploadWork() {
              (0, _jquery2['default'])('#upload').click();
          },
          // 创建相册还是编辑相册
          createGallery: function createGallery() {
              var _this = this;
  
              var url = constant.API.USER_GALLERY;
              if (!this.gname) return;
              if (this.cate === 'all') return;
              var data = {
                  name: this.gname,
                  scate: this.scate,
                  desc: this.gdesc,
                  download_url: this.download_url,
                  concept: this.concept,
                  fname: this.fname
              };
              var ajax = _srcAssetsJsApi2['default'].post;
              if (this.type === 'patch') {
                  ajax = _srcAssetsJsApi2['default'].patch;
                  url += this.gid + '/';
              }
              ajax({
                  url: url,
                  data: data
              }).done(function () {
                  _this.showModal = false;
                  _this.$broadcast('createGallery', true);
              });
          }
      },
      data: function data() {
          return {
              scates: [],
              // 同步显示上传work的遮罩
              view_count: 0,
              like_count: 0,
              role: '',
              gname: '', // 相册名称
              gdesc: '', // 相册描述
              name: '',
              gender: '',
              desc: '',
              gid: '',
              age: '',
              avatar: '',
              scate: '',
              showModal: false,
              type: 'create', // new: 创建新的相册， add: 添加新的作品,  none: overlay;
              fname: '',
              download_url: '',
              concept: '',
              province: '',
              available_cash_points: '',
              city: '',
              is_recommend: '',
              available_points: '',
              audit_status: '',
              download_count: '',
              career: '',
              license_pic: '',
              id: '',
              mobile: '',
              apply_count: '',
              paied_points: '',
              license_id: '',
              gallery_count: '',
              remaining: ''
          };
      }
  };
  module.exports = exports['default'];
  var __vue__options__;
  if(exports && exports.__esModule && exports.default){
    __vue__options__ = exports.default;
  }else{
    __vue__options__ = module.exports;
  }
  __vue__options__.template = "<dheader></dheader><modal :show.sync=\"showModal\" :css=\"{width: 640, height: 600}\" class=\"addGallery\"><header slot=\"header\">新建相册</header><div slot=\"body\" __vuec__f01446d3=\"__vuec__f01446d3\" class=\"body\"><div class=\"mt-20\"><label>相册名称</label><input v-model=\"gname\" placeholder=\"相册名称\" class=\"name ml-20\"/></div><div class=\"mt-20\"><label class=\"fl\">选择分类</label><select v-model=\"scate\" placeholder=\"相册名称\" class=\"fl name ml-20\"><option value=\"all\" selected=\"selected\">请选择</option><option v-for=\"scate in scates\">{{scate}}</option></select></div><div class=\"clear\"></div><div class=\"mt-30\"><label>描述</label><textarea v-model=\"gdesc\" placeholder=\"相册描述\" class=\"desc ml-20\"></textarea></div><div class=\"mt-20\"><label>设计理念</label><textarea v-model=\"concept\" placeholder=\"请描述您作品的设计理念\" class=\"desc ml-20\"></textarea></div></div><div slot=\"footer\"><div class=\"btn mr-20 fr\"><a v-if=\"type === 'create'\" @click=\"createGallery\">确定</a><a @click=\"createGallery\">保存</a></div></div></modal><div __vuec__f01446d3=\"__vuec__f01446d3\" class=\"profile\"><tab></tab><div class=\"bfc detail mt-20\"><div class=\"avatar-container\"><div class=\"avatar fl\">?<img :src=\"avatar\"/></div><div class=\"desc bfc\"><div class=\"fl ml-40\"><a class=\"active\">{{name}}</a></div><div class=\"fl ml-10\">的个人空间</div><div class=\"fr addWork btn\"><a @click=\"showModal = true\">添加作品</a></div></div></div><div class=\"clear\"></div><!-- 用户自己的个人空间--><gallery :uid=\"id\" :type=\"type\"></gallery></div></div>"
  

});
