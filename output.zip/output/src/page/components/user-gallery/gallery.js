define('src/page/components/user-gallery/gallery.vue', function(require, exports, module) {

  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  
  'use strict';
  
  Object.defineProperty(exports, '__esModule', {
      value: true
  });
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _srcAssetsJsPage = require('src/assets/js/page');
  
  var _srcAssetsJsConstant = require('src/assets/js/constant');
  
  var _srcAssetsJsConstant2 = _interopRequireDefault(_srcAssetsJsConstant);
  
  var _srcAssetsJsApi = require('src/assets/js/api');
  
  var _srcAssetsJsApi2 = _interopRequireDefault(_srcAssetsJsApi);
  
  var _srcAssetsJsUtils = require('src/assets/js/utils');
  
  var _srcAssetsJsUtils2 = _interopRequireDefault(_srcAssetsJsUtils);
  
  var _srcPageComponentsGalleryOverlayOverlay = require('src/page/components/gallery-overlay/overlay.vue');
  
  var _srcPageComponentsGalleryOverlayOverlay2 = _interopRequireDefault(_srcPageComponentsGalleryOverlayOverlay);
  
  var _srcPageComponentsGalleryDetailGalleryDetail = require('src/page/components/gallery-detail/gallery-detail.vue');
  
  var _srcPageComponentsGalleryDetailGalleryDetail2 = _interopRequireDefault(_srcPageComponentsGalleryDetailGalleryDetail);
  
  var _srcPageComponentsUploadWorkUploadWork = require('src/page/components/upload-work/upload-work.vue');
  
  var _srcPageComponentsUploadWorkUploadWork2 = _interopRequireDefault(_srcPageComponentsUploadWorkUploadWork);
  
  var _srcPublicPaginatorPaginator = require('src/public/paginator/paginator.vue');
  
  var _srcPublicPaginatorPaginator2 = _interopRequireDefault(_srcPublicPaginatorPaginator);
  
  var _jquery = require('node_modules/jquery/dist/jquery');
  
  var _jquery2 = _interopRequireDefault(_jquery);
  
  var _srcPublicModalModal = require('src/public/modal/modal.vue');
  
  var _srcPublicModalModal2 = _interopRequireDefault(_srcPublicModalModal);
  
  exports['default'] = {
      props: ['uid', 'type'],
      components: {
          overlay: _srcPageComponentsGalleryOverlayOverlay2['default'],
          gallerydetail: _srcPageComponentsGalleryDetailGalleryDetail2['default'],
          uploadwork: _srcPageComponentsUploadWorkUploadWork2['default'],
          paginator: _srcPublicPaginatorPaginator2['default'],
          modal: _srcPublicModalModal2['default']
      },
      events: {
          createGallery: function createGallery(success) {
              if (success) {
                  this.reloadAsyncData();
              }
          },
          closeModal: function closeModal() {
              this.reloadAsyncData();
          },
          confirmModal: function confirmModal(data) {
              var _this = this;
  
              // 确认删除
              if (data.action === 'deleteGallery') {
                  this.showModal = false;
                  _srcAssetsJsApi2['default']['delete']({
                      url: this.url + this.gid + '/'
                  }).done(function () {
                      return _this.reloadAsyncData();
                  });
              }
          }
      },
      asyncData: function asyncData(resolve, reject) {
          if (!this.uid) {
              return;
          }
          var self = this;
          this.fetch().done(function () {
              this.gallerys = this.data.galleries;
              this.cates = this.data.cates;
              self.$dispatch('getCates', this.data.cates);
              resolve(this);
          });
      },
      watch: {
          uid: function uid() {
              this.reloadAsyncData();
          },
          query: {
              deep: true,
              handler: function handler() {
                  this.reloadAsyncData();
              }
          }
      },
      methods: {
          // 获取基本信息
          fetch: function fetch() {
              this.uid = this.uid || _srcAssetsJsUtils2['default'].getURLParam('uid');
              this.url = _srcAssetsJsConstant2['default'].API.USER + this.uid + _srcAssetsJsConstant2['default'].API.GALLERY;
              return _srcAssetsJsApi2['default'].get({
                  url: this.url,
                  data: this.query
              });
          },
          // 点赞功能
          likeIt: function likeIt(id) {
              var url = _srcAssetsJsConstant2['default'].API.LIKE_IT + id + '/';
              var self = this;
              _srcAssetsJsApi2['default'].post({
                  url: url
              }).done(function () {
                  self.reloadAsyncData();
              });
          },
          // 父组件向子组件派发请求
          // 弹出相册遮罩，展示详细展开包的信息，和更多相册信息
          showOverlay: function showOverlay(gallery) {
              console.info(this.type);
              this.$broadcast('changeGallery', {
                  data: gallery,
                  showModal: true
              });
              this.isShowDetail = true;
              this.detailProp = gallery;
          },
          closeGallery: function closeGallery() {
              this.isShowDetail = false;
              this.detailProp = {};
          },
          // 切换排序
          changeSort: function changeSort(e) {
              var el = e.currentTarget;
              var order = el.value;
              this.query = {
                  order_by: order
              };
          },
          // 按照分类筛选相册
          searchCate: function searchCate(e) {
              var el = e.currentTarget;
              var scate = el.value;
              this.query = {
                  scate: scate
              };
          },
          // 编辑相册
          editGallery: function editGallery(gallery) {
              this.$dispatch('editGallery', gallery);
          },
          // 弹出警告弹窗删除相册
          deleteGallery: function deleteGallery(id) {
              this.showModal = true;
              this.gid = id;
          },
          showEditbar: function showEditbar(e) {
              var el = e.target;
              var $el = (0, _jquery2['default'])(el);
              $el.find('.edit-bar').show();
          },
          hideEditbar: function hideEditbar(e) {
              var el = e.target;
              var $el = (0, _jquery2['default'])(el);
              $el.find('.edit-bar').hide();
          },
          changePage: function changePage(page) {
              _srcAssetsJsPage.Vue.set(this.query, 'page', page);
          }
      },
      data: function data() {
          return {
              url: '',
              gid: '', //当前相册的ID
              query: {},
              cates: [],
              info: {},
              data: {},
              success: false,
              gallerys: [],
              showModal: false,
              deleteModalCSS: {
                  width: 420,
                  height: 200
              },
              detailProp: {},
              isShowDetail: false
          };
      }
  };
  module.exports = exports['default'];
  var __vue__options__;
  if(exports && exports.__esModule && exports.default){
    __vue__options__ = exports.default;
  }else{
    __vue__options__ = module.exports;
  }
  __vue__options__.template = "<div class=\"sort\"><div class=\"container\"><div class=\"condition\"><select @change=\"changeSort\" class=\"fl\"><option value=\"created_on\" class=\"fl ml-20\">创建时间</option><option value=\"view_count\">热度</option><option value=\"like_count\">点赞</option></select><select @change=\"searchCate\" class=\"fl ml-20\"><option value=\"All\">全部</option><option v-for=\"opt in cates\" value=\"{{opt}}\">{{opt}}</option></select></div></div></div><div __vuec__f5b15043=\"__vuec__f5b15043\" class=\"wrap-inner\"><div class=\"content\"><ol class=\"gallerys\"><li v-for=\"(outter, gallery) in gallerys\" @mouseenter=\"showEditbar\" @mouseleave=\"hideEditbar\"><div class=\"gallery fl\"><div v-if=\"!!type\" class=\"edit-bar\"><div @click=\"editGallery(gallery)\" class=\"edit fl ml-20\"></div><div @click=\"deleteGallery(gallery.id)\" class=\"delete fr mr-10\"></div></div><div class=\"wrap\"><a @click=\"showOverlay(gallery)\" href=\"javascript:;\"><img :src=\"gallery.thumb\" border=\"0\"/></a><div class=\"fr mt-10\"><span class=\"watching\">{{gallery.view_count}}</span><span @click=\"likeIt(gallery.id, gallery.uid)\" class=\"liking ml-20\">{{gallery.like_count}}</span></div></div><div class=\"avatar\"><div class=\"img\"><img :src=\"gallery.user_avatar\" class=\"ml-20\"/></div><div class=\"ml-40 name\">{{gallery.name}}</div></div></div></li></ol><div class=\"clear\"></div></div><div class=\"clear\"></div><paginator :info=\"info\" :size=\"9\"></paginator></div><gallerydetail v-if=\"isShowDetail &amp;&amp; !type\" :detail=\"detailProp\"> </gallerydetail><uploadwork v-if=\"!!type\"></uploadwork><modal :show.sync=\"showModal\" type=\"warning\" action=\"deleteGallery\" :css=\"deleteModalCSS\" text=\"你确认要删除相册吗？\" subtext=\"在首页、个人作品展示登出的相册也将删除\"><header slot=\"header\">删除提醒</header></modal>"
  

});
