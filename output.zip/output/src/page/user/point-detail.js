define('src/page/user/point-detail.vue', function(require, exports, module) {

  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  
  'use strict';
  
  Object.defineProperty(exports, '__esModule', {
      value: true
  });
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _srcAssetsJsPage = require('src/assets/js/page');
  
  var _srcPageUserTab = require('src/page/user/tab.vue');
  
  var _srcPageUserTab2 = _interopRequireDefault(_srcPageUserTab);
  
  var _srcAssetsJsApi = require('src/assets/js/api');
  
  var _srcAssetsJsApi2 = _interopRequireDefault(_srcAssetsJsApi);
  
  exports['default'] = {
      name: "point-detail",
      components: {
          dheader: _srcAssetsJsPage.dheader,
          dfooter: _srcAssetsJsPage.dfooter,
          tab: _srcPageUserTab2['default']
      },
      asyncData: function asyncData(resolve, reject) {
          _srcAssetsJsApi2['default'].get({
              url: '/api/points/'
          }).done(function () {
              this.pointsList = this.data;
              resolve(this);
          });
      },
      data: function data() {
          return {
              tabActive: 'record', // record 记录  putforward 提现
              pointsFormData: {},
              pointsList: []
          };
      },
      ready: function ready() {
          console.log(this);
      },
      methods: {
          pointsSubmit: function pointsSubmit() {
              var self = this;
              _srcAssetsJsApi2['default'].post({
                  url: '/api/withdraws/',
                  data: this.pointsFormData
              }).done(function () {
                  self.pointsFormData = {};
                  alert("提交成功!");
              });
          }
      }
  };
  module.exports = exports['default'];
  var __vue__options__;
  if(exports && exports.__esModule && exports.default){
    __vue__options__ = exports.default;
  }else{
    __vue__options__ = module.exports;
  }
  __vue__options__.template = "<dheader></dheader><div __vuec__9abcced6=\"__vuec__9abcced6\" class=\"profile\"><tab></tab><div class=\"bfc detail mt-20\"><div class=\"tab-switch\"><div @click=\"tabActive = 'record'\" :class=\"{active:tabActive === 'record'}\" class=\"a\">积分记录</div><div @click=\"tabActive = 'putForward'\" :class=\"{active:tabActive === 'putForward'}\" class=\"b\">积分提现</div></div><div v-if=\"tabActive === 'record'\" class=\"tab-main\"><div class=\"item\"><div class=\"num1\">积分</div><div class=\"num2\">交易时间</div><div class=\"num3\">交易类型</div></div><div v-for=\"(index, item) in pointsList\" class=\"item\"><div v-if=\"item.points_type == 1\" class=\"num1\">+ {{item.points}}</div><div v-if=\"item.points_type == 2\" class=\"num1\">+ {{item.points}}</div><div v-if=\"item.points_type == 3\" class=\"num1\">- {{item.points}}</div><div v-if=\"item.points_type == 4\" class=\"num1\">+ {{item.points}}</div><div v-if=\"item.points_type == 5\" class=\"num1\">- {{item.points}}</div><div class=\"num2\">{{item.created_on}}</div><div v-if=\"item.points_type == 1\" class=\"num3\">积分充值</div><div v-if=\"item.points_type == 2\" class=\"num3\">订单积分获取</div><div v-if=\"item.points_type == 3\" class=\"num3\">订单积分支付</div><div v-if=\"item.points_type == 4\" class=\"num3\">相册积分获取</div><div v-if=\"item.points_type == 5\" class=\"num3\">相册积分支付</div></div></div><div v-else=\"tabActive === 'putForward'\" class=\"tab-main\"><div class=\"tab-main-header\"><p style=\"color:#000;font-weight:bold;\">可提现积分<span style=\"color:#4195f7;\">123，折换成人民币¥</span><span style=\"color:#ff0000;\">{{321}}</span></p><p>(1积分=1人民币，满100积分可提现）</p></div><div class=\"form\"><div class=\"form-item\"><input v-model=\"pointsFormData.points\" placeholder=\"请输入提现金额￥（提现金额必须是10的倍数）\" class=\"input\"/><br/></div><div class=\"form-item\"><input v-model=\"pointsFormData.card_number\" placeholder=\"请输入银行卡账号\" class=\"input\"/><br/></div><div class=\"form-item\"><input v-model=\"pointsFormData.card_name\" placeholder=\"请输入开户行信息\" class=\"input\"/><br/></div><div class=\"form-item\"><input v-model=\"pointsFormData.username\" placeholder=\"请输入您的真实姓名\" class=\"input\"/><br/></div><div class=\"form-item\"><input type=\"number\" v-model=\"pointsFormData.mobile\" placeholder=\"请输入手机号码\" class=\"input\"/><br/></div><div @click=\"pointsSubmit\" class=\"submit\">提交申请</div></div><div class=\"footer\"><p>提现说明：</p><p>1、提现仅能在每周二申请，审核通过后会在1至7个工作日内打款</p><p>2、请务必确认以上信息完全正确才能收到提现款</p><p>3、如有疑问请<a style=\"color:#00a0e9;\" href=\"mailto:1776261265@qq.com\">联系我们</a></p></div></div></div></div>"
  

});
