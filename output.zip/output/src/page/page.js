define('src/page/page', function(require, exports, module) {

  /**
    @file: bootstrap script
    @date: 2016-07-25
  */
  
  // bootstrap the app
  'use strict';
  
  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _vue = require('node_modules/vue/dist/vue.common');
  
  var _vue2 = _interopRequireDefault(_vue);
  
  var _vueRouter = require('node_modules/vue-router/dist/vue-router');
  
  var _vueRouter2 = _interopRequireDefault(_vueRouter);
  
  _vue2['default'].use(_vueRouter2['default']);
  var router = new _vueRouter2['default']();
  
  // import dynamic app, need route map for app
  
  exports['default'] = function (App) {
    router.start(App, 'app');
    return router;
  };
  
  module.exports = exports['default'];

});
