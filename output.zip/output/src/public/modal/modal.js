define('src/public/modal/modal.vue', function(require, exports, module) {

  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  
  'use strict';
  
  Object.defineProperty(exports, '__esModule', {
      value: true
  });
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _jquery = require('node_modules/jquery/dist/jquery');
  
  var _jquery2 = _interopRequireDefault(_jquery);
  
  var _lodash = require('node_modules/lodash/lodash');
  
  var _lodash2 = _interopRequireDefault(_lodash);
  
  exports['default'] = {
      props: {
          show: {
              type: Boolean,
              required: true,
              twoWay: true
          },
          css: {
              type: Object,
              required: false
          },
          type: {
              type: String
          },
          action: {
              type: String
          },
          text: {
              type: String
          },
          subtext: {
              type: String
          }
      },
      ready: function ready() {
          var $el = (0, _jquery2['default'])(this.$el);
          if (_lodash2['default'].isObject(this.css)) {
              $el.find('.modal-container').css(this.css);
          }
      },
      methods: {
          stopPropagation: function stopPropagation(e) {
              e.stopPropagation();
          },
          close: function close() {
              this.show = false;
              this.$dispatch('closeModal', true);
          },
          confirm: function confirm() {
              this.$dispatch('confirmModal', {
                  type: this.type,
                  action: this.action
              });
          }
      },
      data: function data() {
          return {};
      }
  };
  module.exports = exports['default'];
  var __vue__options__;
  if(exports && exports.__esModule && exports.default){
    __vue__options__ = exports.default;
  }else{
    __vue__options__ = module.exports;
  }
  __vue__options__.template = "<div v-show=\"show\" transition=\"modal\" @click=\"close\" class=\"modal-mask\"><div class=\"modal-wrapper\"><div @click=\"stopPropagation\" class=\"modal-container\"><div class=\"modal-header\"><slot name=\"header\" class=\"slot-header\">default header</slot><a @click=\"close\" class=\"close fr\"><img src=\"/src/public/modal/close.png\"/></a></div><div class=\"modal-body clear\"><div v-if=\"!!type\" class=\"fl icon ml-40 icon-{{type}}\"></div><div class=\"slot-body\"><slot name=\"body\"><div class=\"text\">{{text}}</div><div class=\"sub-text mt-10\">{{subtext}}</div></slot></div></div><div class=\"modal-footer\"><slot name=\"footer\" class=\"slot-footer\"><div @click=\"confirm\" class=\"btn fr mr-20\"><a>确认</a></div><div @click=\"close\" class=\"btn btn-gray fr mr-20\"><a>取消</a></div></slot></div></div></div></div>"
  

});
