define('src/assets/js/api', function(require, exports, module) {

  /**
   * @file: 封装了后端异常自动提示，ajax请求
   * @author: senli
   * @date: 2015-10-16
   *
   * */
  
  'use strict';
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _jquery = require('node_modules/jquery/dist/jquery');
  
  var _jquery2 = _interopRequireDefault(_jquery);
  
  var _lodash = require('node_modules/lodash/lodash');
  
  var _lodash2 = _interopRequireDefault(_lodash);
  
  var API = {};
  var message = {};
  message.TIP = {
      TIP_ID: 'YJS-TIP-1',
      TIP_TITLE_SUCCESS: '成功：',
      TIP_TITLE_WARN: '警告!',
      TIP_TITLE_ERROR: '错误：',
      TIP_CLASS_SUCCESS: 'success',
      TIP_CLASS_WARN: 'warn',
      TIP_CLASS_ERROR: 'error',
      PREVIEW: '效果预览'
  };
  message.ERRORS = {
      HTTP: {
          304: '请求内容没有改变',
          400: '请求失效',
          401: '未认证的用户请求',
          403: '禁止， 请求未被认证',
          404: '该方法不存在',
          405: '方法未被允许， 不正确的HTTP方法',
          415: '不支持的媒体类型， 响应不是一个有效的JSON格式',
          500: '服务器异常',
          504: '请求超时'
      }
  };
  
  function tipErrors(message) {
      if (message) {
          window.alert(message);
      }
  }
  /*
   * @description: 全局的AJAX封装，错误提示已经封装好了
   *
   * */
  
  /* eslint-disable fecs-camelcase, new-cap */
  
  API.ajax = function (options) {
      var defered = _jquery2['default'].Deferred();
      var resolve = defered.resolve;
      var reject = defered.reject;
      var promise = defered.promise;
      options.url || (options.url = '/');
      if (!_lodash2['default'].endsWith(options.url, '/') && options.url.length !== 0 && !options.isNeed) {
          options.url += '/';
      }
      options = _lodash2['default'].merge({}, {
          type: 'post',
          contentType: 'application/json',
          dataType: 'json',
          data: {},
          success: function success(resp) {
              var success = resp.success;
              var data = resp.data;
              /* eslint-disable fecs-camelcase */
              var pageInfo = resp.page_info;
              // resolve, reject
              if (success) {
                  resolve.call({
                      data: data,
                      info: pageInfo,
                      success: success
                  });
                  options.callback && options.callback();
                  return;
              }
              reject();
              tipErrors(resp.message);
          },
          error: function error(err) {
              tipErrors(err.stauts);
          }
  
      }, options);
      if (options.type.toLowerCase() !== 'get' && options.contentType === 'application/json') {
          options.data = JSON.stringify(options.data);
      }
      _jquery2['default'].ajax(options);
      return promise();
  };
  API.get = function (options) {
      options.type = 'get';
      return API.ajax(options);
  };
  
  API.post = function (options) {
      return API.ajax(options);
  };
  
  API['delete'] = function (options) {
      options.headers = {
          'X-Http-Method-Override': 'DELETE'
      };
      return API.ajax(options);
  };
  
  API.patch = function (options) {
      options.headers = {
          'X-Http-Method-Override': 'PATCH'
      };
      return API.ajax(options);
  };
  
  API.put = function (options) {
      options.headers = {
          'X-Http-Method-Override': 'PUT'
      };
      return API.ajax(options);
  };
  
  module.exports = API;

});
