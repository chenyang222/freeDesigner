define('src/page/components/login/login.vue', function(require, exports, module) {

  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  
  'use strict';
  
  Object.defineProperty(exports, '__esModule', {
      value: true
  });
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _srcAssetsJsConstant = require('src/assets/js/constant');
  
  var _srcAssetsJsConstant2 = _interopRequireDefault(_srcAssetsJsConstant);
  
  var _srcAssetsJsApi = require('src/assets/js/api');
  
  var _srcAssetsJsApi2 = _interopRequireDefault(_srcAssetsJsApi);
  
  exports['default'] = {
      methods: {
          login: function login() {
              var data = {
                  mobile: this.mobile,
                  password: this.password
              };
              _srcAssetsJsApi2['default'].post({
                  url: _srcAssetsJsConstant2['default'].API.LOGIN,
                  data: data
              }).done(function () {
                  window.location.href = _srcAssetsJsConstant2['default'].PATH.HOME;
              });
          }
      },
      data: function data() {
          return {
              mobile: '',
              password: ''
          };
      }
  };
  module.exports = exports['default'];
  var __vue__options__;
  if(exports && exports.__esModule && exports.default){
    __vue__options__ = exports.default;
  }else{
    __vue__options__ = module.exports;
  }
  __vue__options__.template = "<div class=\"title\">登录</div><div class=\"fl mt-100\"><div><label>输入您的手机号码</label><input v-model=\"mobile\" placeholder=\"请输入您注册的手机号\"/></div><div class=\"mt-20\"><label>输入密码</label><input v-model=\"password\" type=\"password\" placeholder=\"请输入密码\"/></div><div class=\"mt-20\"><div @click=\"login\" class=\"btn\"><a href=\"javascript:;\">登录</a></div></div></div><div class=\"slogon fl ml-40 mt-100\"><img src=\"/src/page/login/logo.png\"/><div class=\"mt-10\">Free interior Designer</div><div style=\"margin-top:5px; font-size: 14px;\">室内设计师场景的合作交易平台</div></div><div class=\"clear\"></div><div class=\"bottom mt-100\"><a href=\"/register/register.html\">没有注册吗？</a></div>"
  

});
