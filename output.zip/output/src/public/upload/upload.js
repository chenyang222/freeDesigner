define('src/public/upload/upload.vue', function(require, exports, module) {

  //
  //
  //
  
  'use strict';
  
  Object.defineProperty(exports, '__esModule', {
      value: true
  });
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _srcAssetsJsApi = require('src/assets/js/api');
  
  var _srcAssetsJsApi2 = _interopRequireDefault(_srcAssetsJsApi);
  
  var _srcAssetsJsUtils = require('src/assets/js/utils');
  
  var _srcAssetsJsUtils2 = _interopRequireDefault(_srcAssetsJsUtils);
  
  exports['default'] = {
      props: {
          maxsize: {
              'default': 5 * 1024 * 100
          },
          type: {
              'default': 'work'
          },
          subtype: {
              'default': ''
          },
          id: {
              'default': 'upload'
          }
      },
      ready: function ready() {
          this.MAX_SIZE = this.maxsize * 1024; // *KB
          this.FILE_NAME_NOT_CONTAINS = [';']; // 文件名不能包含的内容
      },
      computed: {
          accept: function accept() {
              var accept = '*';
              switch (this.type) {
                  case 'avatar':
                  case 'work':
                  case 'order_work':
                      accept = 'image/png, image/jpeg, image/jpg, image/gif';
                      break;
                  case 'deliveries':
                  case 'resource':
                      accept = '*';
                      break;
                  case 'camera':
                      accept = 'image/*';
                      break;
              }
              return accept;
          }
      },
      methods: {
          onUploadComplete: function onUploadComplete(e) {
              var resp = e.target.responseText;
              var ret = JSON.parse(resp);
              this.$dispatch('uploadComplete', {
                  data: ret.data,
                  fname: this.fname,
                  subtype: this.subtype
              });
          },
          onUploadProgress: function onUploadProgress(e) {
              this.$dispatch('uploadProgress', e);
          },
          uploadImage: function uploadImage(e) {
              var files = e.target.files;
              var file = files[0];
              var fileName = file.name;
              var fileSize = file.size;
              this.fname = fileName;
              // 文件大小不能为0
              if (fileSize === 0) {
                  window.alert('文件大小不能为0');
                  this.value = '';
                  return false;
              }
              if (fileSize > this.MAX_SIZE) {
                  window.alert('文件不能超过' + _srcAssetsJsUtils2['default'].parseSize(this.MAX_SIZE).html);
                  return;
              }
              var fd = new FormData();
              fd.append('content', file);
              fd.append('ftype', this.type);
              var xhr = new XMLHttpRequest();
              xhr.upload.addEventListener('progress', this.onUploadProgress);
              xhr.addEventListener('load', this.onUploadComplete);
              xhr.addEventListener('error', this.onUploadFailed);
              // xhr.addEventListener('abort', this.onUploadCanceled);
              xhr.open('POST', constant.API.UPLOAD_FILE);
              xhr.send(fd);
              e.target.value = '';
          }
      },
      data: function data() {
          return {
              fname: ''
          };
      }
  };
  module.exports = exports['default'];
  var __vue__options__;
  if(exports && exports.__esModule && exports.default){
    __vue__options__ = exports.default;
  }else{
    __vue__options__ = module.exports;
  }
  __vue__options__.template = "<input @change=\"uploadImage\" type=\"file\" :accept=\"accept\" hidden=\"hidden\" :id=\"id\"/>"
  

});
