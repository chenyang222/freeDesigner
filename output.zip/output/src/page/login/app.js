define('src/page/login/app.vue', function(require, exports, module) {

  //
  //
  //
  //
  
  'use strict';
  
  Object.defineProperty(exports, '__esModule', {
      value: true
  });
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  require('src/assets/js/page');
  
  var _srcPageComponentsLoginLogin = require('src/page/components/login/login.vue');
  
  var _srcPageComponentsLoginLogin2 = _interopRequireDefault(_srcPageComponentsLoginLogin);
  
  exports['default'] = {
      components: {
          login: _srcPageComponentsLoginLogin2['default']
      },
      methods: {},
      data: function data() {
          return {};
      }
  };
  module.exports = exports['default'];
  var __vue__options__;
  if(exports && exports.__esModule && exports.default){
    __vue__options__ = exports.default;
  }else{
    __vue__options__ = module.exports;
  }
  __vue__options__.template = "<div class=\"container\"><login></login></div>"
  

});
