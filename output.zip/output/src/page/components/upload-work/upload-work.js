define('src/page/components/upload-work/upload-work.vue', function(require, exports, module) {

  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  
  'use strict';
  
  Object.defineProperty(exports, '__esModule', {
      value: true
  });
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _srcAssetsJsConstant = require('src/assets/js/constant');
  
  var _srcAssetsJsConstant2 = _interopRequireDefault(_srcAssetsJsConstant);
  
  var _srcAssetsJsApi = require('src/assets/js/api');
  
  var _srcAssetsJsApi2 = _interopRequireDefault(_srcAssetsJsApi);
  
  var _srcPublicModalModal = require('src/public/modal/modal.vue');
  
  var _srcPublicModalModal2 = _interopRequireDefault(_srcPublicModalModal);
  
  var _srcPublicUploadUpload = require('src/public/upload/upload.vue');
  
  var _srcPublicUploadUpload2 = _interopRequireDefault(_srcPublicUploadUpload);
  
  exports['default'] = {
      components: {
          modal: _srcPublicModalModal2['default'],
          upload: _srcPublicUploadUpload2['default']
      },
      // 接受父组件广播过来的事件
      events: {
          changeGallery: function changeGallery(params) {
              this.show = params.showModal || false;
              var gid = params.data.id;
              this.url = _srcAssetsJsConstant2['default'].API.USER_GALLERY + gid + _srcAssetsJsConstant2['default'].API.IMAGE;
          },
          uploadComplete: function uploadComplete(resp) {
              var _this = this;
  
              var data = {
                  name: '',
                  image: resp.data
              };
              _srcAssetsJsApi2['default'].post({
                  url: this.url,
                  data: data
              }).done(function () {
                  _this.reloadAsyncData();
              });
          }
      },
      asyncData: function asyncData(resolve) {
          if (!this.url) {
              return;
          }
          this.fetch().done(function () {
              this.works = this.data;
              resolve(this);
          });
      },
      watch: {
          url: function url() {
              this.reloadAsyncData();
          }
      },
      methods: {
  
          // 上传作品到指定的相册，如果没有，则新建
          uploadWork: function uploadWork() {
              document.getElementById('upload').click();
          },
          fetch: function fetch() {
              return _srcAssetsJsApi2['default'].get({
                  url: this.url
              });
          },
          deleteWork: function deleteWork(id) {
              var _this2 = this;
  
              _srcAssetsJsApi2['default']['delete']({
                  url: this.url + id + '/'
              }).done(function () {
                  return _this2.reloadAsyncData();
              });
          }
      },
      data: function data() {
          return {
              works: [],
              url: '',
              show: false,
              data: {},
              info: {},
              success: false
          };
      }
  };
  module.exports = exports['default'];
  var __vue__options__;
  if(exports && exports.__esModule && exports.default){
    __vue__options__ = exports.default;
  }else{
    __vue__options__ = module.exports;
  }
  __vue__options__.template = "<modal :show.sync=\"show\" :css=\"{width: 640, height: 600}\"><div slot=\"header\" class=\"slot-header\">上传作品</div><div slot=\"body\" __vuec__95eba6e8=\"__vuec__95eba6e8\" class=\"slot-body mt-40\"><ul class=\"works mt-30\"><li v-for=\"work in works\"><div @click=\"deleteWork(work.id)\" class=\"close\">x</div><a @mouseenter=\"show\"><img :src=\"work.mid_image\"/></a></li><li @click=\"uploadWork\" class=\"upload\">+</li></ul><upload type=\"work\"></upload></div><div slot=\"footer\"></div></modal>"
  

});
