define('src/page/components/work/work.vue', function(require, exports, module) {

  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  
  'use strict';
  
  Object.defineProperty(exports, '__esModule', {
      value: true
  });
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _srcAssetsJsApi = require('src/assets/js/api');
  
  var _srcAssetsJsApi2 = _interopRequireDefault(_srcAssetsJsApi);
  
  var _srcAssetsJsConstant = require('src/assets/js/constant');
  
  var _srcAssetsJsConstant2 = _interopRequireDefault(_srcAssetsJsConstant);
  
  var _jquery = require('node_modules/jquery/dist/jquery');
  
  var _jquery2 = _interopRequireDefault(_jquery);
  
  exports['default'] = {
      props: ['ids'],
      asyncData: function asyncData(resolve, reject) {
          if (!this.ids.uid || !this.ids.id) {
              return;
          }
          this.fetch().done(function () {
              this.works = this.data;
              resolve(this);
          });
      },
      watch: {
          ids: {
              deep: true,
              handler: function handler(val) {
                  this.url = _srcAssetsJsConstant2['default'].API.USER + val.uid + _srcAssetsJsConstant2['default'].API.GALLERY + val.id + _srcAssetsJsConstant2['default'].API.IMAGE;
                  this.index = 0;
                  this.reloadAsyncData();
              }
          }
      },
      methods: {
          fetch: function fetch() {
              return _srcAssetsJsApi2['default'].get({
                  url: this.url
              });
          },
          slideWorkList: function slideWorkList(isRight) {
              var isLeft = !isRight;
              var $works = (0, _jquery2['default'])(this.$el).find('.works').eq(0);
              var marginLeft = parseInt($works.css('marginLeft'), 10) || 0;
              var worksWidth = $works.width();
              var offset = 104;
              if (isLeft && marginLeft !== 0) {
                  $works.css('marginLeft', marginLeft + offset);
              }
              console.log(this.showWidth - marginLeft);
              console.log(worksWidth);
              console.log(this.showWidth - marginLeft <= worksWidth);
              if (isRight && this.showWidth - marginLeft <= worksWidth) {
                  $works.css('marginLeft', marginLeft - offset);
              }
          },
          changeWork: function changeWork(index) {
              this.index = index;
          }
      },
      data: function data() {
          return {
              url: _srcAssetsJsConstant2['default'].API.USER + this.ids.uid + _srcAssetsJsConstant2['default'].API.GALLERY + this.ids.id + _srcAssetsJsConstant2['default'].API.IMAGE,
              index: 0, // 默认的相册里面的第一张图片
              works: [{}],
              data: [],
              info: {},
              success: false,
              showWidth: 292 // 幻灯片显示的宽度
          };
      }
  };
  module.exports = exports['default'];
  var __vue__options__;
  if(exports && exports.__esModule && exports.default){
    __vue__options__ = exports.default;
  }else{
    __vue__options__ = module.exports;
  }
  __vue__options__.template = "<div __vuec__021c8069=\"__vuec__021c8069\" class=\"cover\"><a href=\"{{works[index].large_image}}\" target=\"blank\"><img :src=\"works[index].large_image\"/></a><div class=\"slider mt-20\"><div @click=\"slideWorkList(false)\" class=\"fl left\"></div><div class=\"fl works-container\"><div class=\"works\"><span v-for=\"work in works\"><img :src=\"work.small_image\" @click=\"changeWork($index)\"/></span></div></div><div @click=\"slideWorkList(true)\" class=\"fr right\"></div></div></div>"
  

});
