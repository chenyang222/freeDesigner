define('src/page/user/tab.vue', function(require, exports, module) {

  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  
  'use strict';
  
  Object.defineProperty(exports, '__esModule', {
      value: true
  });
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _jquery = require('node_modules/jquery/dist/jquery');
  
  var _jquery2 = _interopRequireDefault(_jquery);
  
  var _srcAssetsJsConstant = require('src/assets/js/constant');
  
  var _srcAssetsJsConstant2 = _interopRequireDefault(_srcAssetsJsConstant);
  
  exports['default'] = {
      ready: function ready() {
          var pathname = _srcAssetsJsConstant2['default'].URL.PATH_NAME;
          console.info(pathname);
          pathname = pathname.split('/');
          pathname = pathname[pathname.length - 1];
          pathname = pathname.replace('.html', '');
          var $el = (0, _jquery2['default'])(this.$el).find('.' + pathname);
          $el.addClass('active');
      },
      data: function data() {
          var profileURL = _srcAssetsJsConstant2['default'].PATH.USER_PROFILE;
          var spaceURL = _srcAssetsJsConstant2['default'].PATH.USER_SPACE;
          var accountURL = _srcAssetsJsConstant2['default'].PATH.USER_ACCOUNT;
          var pointsURL = _srcAssetsJsConstant2['default'].PATH.POINTS_DETAIL;
          return {
              profileURL: profileURL,
              spaceURL: spaceURL,
              accountURL: accountURL,
              pointsURL: pointsURL
          };
      }
  };
  module.exports = exports['default'];
  var __vue__options__;
  if(exports && exports.__esModule && exports.default){
    __vue__options__ = exports.default;
  }else{
    __vue__options__ = module.exports;
  }
  __vue__options__.template = "<ul __vuec__55259318=\"__vuec__55259318\" class=\"tab fl mt-150\"><li class=\"profile\"><a href=\"{{profileURL}}\">基本信息</a></li><li class=\"space\"><a href=\"{{spaceURL}}\">个人空间</a></li><li class=\"account\"><a href=\"{{accountURL}}\">账户安全</a></li><li class=\"points\"><a href=\"{{pointsURL}}\" class=\"last\">积分管理</a></li></ul>"
  

});
