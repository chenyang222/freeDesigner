define('src/page/public/demand.vue', function(require, exports, module) {

  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  
  'use strict';
  
  Object.defineProperty(exports, '__esModule', {
      value: true
  });
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _srcAssetsJsPage = require('src/assets/js/page');
  
  var _srcAssetsJsApi = require('src/assets/js/api');
  
  var _srcAssetsJsApi2 = _interopRequireDefault(_srcAssetsJsApi);
  
  var _srcPageMixins = require('src/page/mixins');
  
  var _srcPageMixins2 = _interopRequireDefault(_srcPageMixins);
  
  var _jquery = require('node_modules/jquery/dist/jquery');
  
  var _jquery2 = _interopRequireDefault(_jquery);
  
  var _srcPublicPaginatorPaginator = require('src/public/paginator/paginator.vue');
  
  var _srcPublicPaginatorPaginator2 = _interopRequireDefault(_srcPublicPaginatorPaginator);
  
  exports['default'] = {
      mixins: [_srcPageMixins2['default']],
      components: {
          dheader: _srcAssetsJsPage.dheader,
          dfooter: _srcAssetsJsPage.dfooter,
          paginator: _srcPublicPaginatorPaginator2['default']
      },
      asyncData: function asyncData(resolve, reject) {
          var self = this;
          _jquery2['default'].when(this.fetch(), this.fetchCategory()).done(function () {
              var applys = this[0];
              var categorys = this[1];
              var obj = {};
              obj.orders = applys.data;
              obj.fcates = categorys.data.fcates;
              obj.scates = categorys.data.scates;
              obj.info = applys.info;
              resolve(obj);
          });
      },
      watch: {
          query: {
              deep: true,
              handler: function handler() {
                  this.reloadAsyncData();
              }
          }
      },
      methods: {
          // 获取未达成合作且未过期的订单列表
          fetch: function fetch() {
              return _srcAssetsJsApi2['default'].get({
                  url: constant.API.DEMAND,
                  data: this.query
              });
          },
          // 获取项目分类，项目需求列表
          fetchCategory: function fetchCategory() {
              return _srcAssetsJsApi2['default'].get({
                  url: '/api/orders/categories/'
              });
          },
          // 过滤项目需求
          changeScate: function changeScate(e) {
              var el = e.currentTarget;
              var val = el.value;
              if (val === 'all') {
                  _srcAssetsJsPage.Vue['delete'](this.query, 'scate');
                  return;
              }
              _srcAssetsJsPage.Vue.set(this.query, 'scate', val);
          },
          // 过滤项目分类
          changeFcate: function changeFcate(e) {
              var el = e.currentTarget;
              var val = el.value;
              if (val === 'all') {
                  _srcAssetsJsPage.Vue['delete'](this.query, 'fcate');
                  return;
              }
              _srcAssetsJsPage.Vue.set(this.query, 'fcate', val);
          },
          changePage: function changePage(page) {
              _srcAssetsJsPage.Vue.set(this.query, 'page', page);
          }
      },
      data: function data() {
          var applyRecordURL = constant.PATH.ORDER_APPLY_RECORD;
          var detailURL = constant.PATH.ORDER_PUB_DETAIL;
          var shareURL = constant.PATH.ORDER_SHARE;
          var publicURL = constant.PATH.USER_PUB;
  
          return {
              orders: {},
              fcate: 'all',
              scate: 'all',
              fcates: [],
              scates: [],
              user_avatar: '',
              query: {},
              publicURL: publicURL,
              shareURL: shareURL,
              detailURL: detailURL,
              applyRecordURL: applyRecordURL
          };
      }
  };
  module.exports = exports['default'];
  var __vue__options__;
  if(exports && exports.__esModule && exports.default){
    __vue__options__ = exports.default;
  }else{
    __vue__options__ = module.exports;
  }
  __vue__options__.template = "<dheader></dheader><div __vuec__18dbdad6=\"__vuec__18dbdad6\" class=\"apply\"><div class=\"banner\"></div><div class=\"select-wrap\"><div class=\"left-wrap fl\"><select v-model=\"fcate\" @change=\"changeFcate\"><option value=\"all\">选择项目分类</option><option v-for=\"opt in fcates\" :value=\"opt\">{{opt}}</option></select></div><div class=\"right-wrap fl\"><select v-model=\"scate\" @change=\"changeScate\"><option value=\"all\">选择项目需求</option><option v-for=\"(opt) in scates\" :value=\"$key\">{{$key}}</option></select></div></div><div class=\"clear mt-20\"></div><div v-for=\"order in orders\" class=\"orders container\"><div class=\"name\">{{order.user_name}}</div><div class=\"avatar fl\"><a href=\"{{publicURL}}?uid={{order.user.id}}\"><img :src=\"order.user.avatar\" class=\"fl\"/></a></div><div title=\"{{order.title}}\" class=\"desc-title fl ellipsis\">{{order.title}}</div><div class=\"system-cost fl ml-100\">{{order.pub_cost/100}}</div><a href=\"{{applyRecordURL}}?oid={{order.id}}\" target=\"_new\" class=\"link\"></a><div class=\"clear\"></div><div class=\"time\"><span class=\"pub\">创建时间：{{order.pub_time | date}}</span><span class=\"deadline ml-40\">交稿日期：{{order.deadline | date}}</span><span class=\"view ml-40\">浏览总计：{{order.view_count}}</span><span class=\"apply ml-40\">接单人数：{{order.apply_count}}</span></div></div><paginator :info=\"info\" class=\"mt-30\"></paginator></div><dfooter> </dfooter>"
  

});
