define('src/page/components/gallery-overlay/overlay.vue', function(require, exports, module) {

  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  
  'use strict';
  
  Object.defineProperty(exports, '__esModule', {
      value: true
  });
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _srcPublicModalModal = require('src/public/modal/modal.vue');
  
  var _srcPublicModalModal2 = _interopRequireDefault(_srcPublicModalModal);
  
  var _srcAssetsJsApi = require('src/assets/js/api');
  
  var _srcAssetsJsApi2 = _interopRequireDefault(_srcAssetsJsApi);
  
  var _srcAssetsJsUtils = require('src/assets/js/utils');
  
  var _srcAssetsJsUtils2 = _interopRequireDefault(_srcAssetsJsUtils);
  
  var _srcPageComponentsGalleryGallery = require('src/page/components/gallery/gallery.vue');
  
  var _srcPageComponentsGalleryGallery2 = _interopRequireDefault(_srcPageComponentsGalleryGallery);
  
  var _srcPageComponentsWorkWork = require('src/page/components/work/work.vue');
  
  var _srcPageComponentsWorkWork2 = _interopRequireDefault(_srcPageComponentsWorkWork);
  
  exports['default'] = {
      components: {
          modal: _srcPublicModalModal2['default'],
          gallery: _srcPageComponentsGalleryGallery2['default'],
          work: _srcPageComponentsWorkWork2['default']
      },
      // 接受其它组件分发过来的事件，hot-gallery 点击
      events: {
          changeGallery: function changeGallery(gallery) {
              this.showModal = gallery.showModal;
              Object.assign(this, gallery.data);
              this.ids = {
                  id: this.id,
                  uid: this.uid
              };
              this.publicURL = constant.PATH.USER_PUB + '?uid=' + this.uid + '&id=' + this.id;
          }
      },
      methods: {
          likeIt: function likeIt() {
              var url = constant.API.LIKE_IT + this.id + '/';
              var self = this;
              _srcAssetsJsApi2['default'].post({
                  url: url
              }).done(function () {
                  self.like_count++;
              });
          }
      },
      data: function data() {
          return {
              showModal: false,
              name: '龙湖御景中式别墅',
              username: '刀刀原创',
              user_avatar: '',
              created_on: '',
              view_count: 0,
              like_count: 0,
              desc: '',
              id: '',
              ids: {
                  uid: '',
                  id: ''
              },
              publicURL: '',
              andSymbol: '&'
          };
      }
  };
  module.exports = exports['default'];
  var __vue__options__;
  if(exports && exports.__esModule && exports.default){
    __vue__options__ = exports.default;
  }else{
    __vue__options__ = module.exports;
  }
  __vue__options__.template = "<modal :show.sync=\"showModal\"><div slot=\"header\" class=\"slot-header\"></div><div slot=\"body\" __vuec__cc443ec3=\"__vuec__cc443ec3\" class=\"slot-body\"><div class=\"avatar\"><a :href=\"publicURL\"><img :src=\"user_avatar\" class=\"fl\"/><div class=\"bfc\"><div class=\"name\">{{name}}</div><div class=\"user\">由{{username}} 上传 {{created_on | date}}</div></div></a></div><div class=\"clear\"></div><div class=\"fl\"><work :ids=\"ids\"></work></div><div class=\"bfc ml-40\"><div class=\"watching\"><label>浏览总量</label><div class=\"fr\">{{view_count}}</div></div><div @click=\"likeIt\" class=\"liking\"><img src=\"/src/page/components/gallery-overlay/like.png\"/><div class=\"fr ml-10\">{{like_count}}</div></div><div class=\"more mt-20\"><div class=\"title\"><a :href=\"publicURL\">更多作品</a></div><gallery :ids=\"ids\" :created_on.sync=\"created_on\"></gallery></div></div><div class=\"clear\"></div><div class=\"desc mt-20\">{{desc}}</div></div><div slot=\"footer\" class=\"slot-footer\"></div></modal>"
  

});
