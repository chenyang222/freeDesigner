define('src/page/order/pub_detail.vue', function(require, exports, module) {

  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  
  'use strict';
  
  Object.defineProperty(exports, '__esModule', {
      value: true
  });
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _srcAssetsJsPage = require('src/assets/js/page');
  
  var _srcAssetsJsApi = require('src/assets/js/api');
  
  var _srcAssetsJsApi2 = _interopRequireDefault(_srcAssetsJsApi);
  
  var _srcPageComponentsOrderDetailOrderDetail = require('src/page/components/order-detail/order-detail.vue');
  
  var _srcPageComponentsOrderDetailOrderDetail2 = _interopRequireDefault(_srcPageComponentsOrderDetailOrderDetail);
  
  var _srcPublicModalModal = require('src/public/modal/modal.vue');
  
  var _srcPublicModalModal2 = _interopRequireDefault(_srcPublicModalModal);
  
  var _srcPublicUploadUpload = require('src/public/upload/upload.vue');
  
  var _srcPublicUploadUpload2 = _interopRequireDefault(_srcPublicUploadUpload);
  
  var _jquery = require('node_modules/jquery/dist/jquery');
  
  var _jquery2 = _interopRequireDefault(_jquery);
  
  var _srcAssetsJsUtils = require('src/assets/js/utils');
  
  var _srcAssetsJsUtils2 = _interopRequireDefault(_srcAssetsJsUtils);
  
  var _srcPageMixins = require('src/page/mixins');
  
  var _srcPageMixins2 = _interopRequireDefault(_srcPageMixins);
  
  var _srcPageOrderOrder_user_info = require('src/page/order/order_user_info.vue');
  
  var _srcPageOrderOrder_user_info2 = _interopRequireDefault(_srcPageOrderOrder_user_info);
  
  exports['default'] = {
      mixins: [_srcPageMixins2['default']],
      components: {
          dheader: _srcAssetsJsPage.dheader,
          orderdetail: _srcPageComponentsOrderDetailOrderDetail2['default'],
          upload: _srcPublicUploadUpload2['default'],
          modal: _srcPublicModalModal2['default'],
          dfooter: _srcAssetsJsPage.dfooter,
          orderUserInfo: _srcPageOrderOrder_user_info2['default']
      },
      events: {
          uploadComplete: function uploadComplete(resp) {
              var data = resp.data[0];
              this.reviseFile = data;
          }
      },
      asyncData: function asyncData(resolve) {
          var self = this;
          this.fetch().done(function () {
              this.order = this.data;
              resolve(this);
              // self.fetchLastComment().done(function () {
              //     this.last_comment = this.data[0];
              //     resolve(this);
              // });
          });
      },
      computed: {
          userInfo: function userInfo() {
              return this.order.apply_records[0];
          },
          showappliers: function showappliers() {
              return this.order.status > constant.ORDER.CONFIRMED;
          },
          showjobs: function showjobs() {
              return this.order.status <= constant.ORDER.CONFIRMED;
          },
          // 第一次修改的按钮禁止
          disabledFirstBtn: function disabledFirstBtn() {
              return this.order.status <= constant.ORDER.FIRST_MODIFY;
          },
          // 第二次修改的按钮禁止
          disabledSecondBtn: function disabledSecondBtn() {
              return this.order.status <= constant.ORDER.SECOND_MODIFY;
          },
          showFirstWork: function showFirstWork() {
              return this.order.status <= constant.ORDER.FIRST_COMMIT;
          },
          showSecondWork: function showSecondWork() {
              return this.order.status <= constant.ORDER.SECOND_COMMIT;
          },
          showThirdWork: function showThirdWork() {
              return this.order.status <= constant.ORDER.THIRD_COMMIT;
          },
          // 确认订单按钮显示
          isConfirmed: function isConfirmed() {
              return this.order.status > 0 && this.order.status <= 80;
          },
          // 确认订单按钮显示
          isFirstCommit: function isFirstCommit() {
              return this.order.status > 0 && this.order.status <= 60;
          },
          aid: function aid() {
              if (!this.order.apply_records) return;
              return this.order.apply_records[0].id;
          },
          otitle: function otitle() {
              var status = this.order.status;
              var CONFIRMED = constant.ORDER.CONFIRMED;
              var title = '发单管理-';
              if (status > CONFIRMED) {
                  title += '未确认订单';
              } else if (status <= CONFIRMED) {
                  title += '已确认订单';
              } else if (status === 0) {
                  title = '已完成订单';
              }
              return title;
          }
      },
      methods: {
          handleRevise: function handleRevise() {
              var self = this;
              _srcAssetsJsApi2['default'].post({
                  url: '/api/orders/' + this.data.id + '/modify_works/',
                  data: {
                      work: this.reviseFile[2],
                      desc: this.reviseVal
                  }
              }).done(function () {
                  self.reviseFile = {};
                  self.reviseVal = '';
                  alert('发起改稿成功');
              });
          },
          uploadZip: function uploadZip() {
              (0, _jquery2['default'])('#upload').click();
          },
          showUserInfo: function showUserInfo(item) {
              this.currentApplyRecords = item;
              this.userInfoVisible = true;
          },
          closeUserInfo: function closeUserInfo() {
              this.userInfoVisible = false;
              this.currentApplyRecords = null;
          },
          fetch: function fetch() {
              return _srcAssetsJsApi2['default'].get({
                  url: this.url
              });
          },
          submit: function submit() {
              var id = this.order.id;
              var evaluateVal = this.evaluateVal;
              _srcAssetsJsApi2['default'].post({
                  url: '/api/orders/' + id + '/finish_orders/'
              }).done(function () {
                  _srcAssetsJsApi2['default'].post({
                      url: '/api/orders/' + id + '/review_applier/',
                      data: {
                          message: evaluateVal
                      }
                  }).done(function () {
                      alert('评价完成！');
                  });
              });
          },
          // 确认之后对单个确认订单的接单人留言
          // 1. 获取发单人的最后一条留言
          fetchLastComment: function fetchLastComment() {
              var aid = this.order.apply_records[0].id;
              var commentURL = constant.API.APPLY_RECORDS + aid + constant.API.ORDER_COMMENTS;
              var data = {
                  order_by: 'created_on',
                  per_page: 1,
                  user: this.order.applier.id
              };
              return _srcAssetsJsApi2['default'].get({
                  url: commentURL,
                  data: data
              });
          },
          // 2. 获取未确认订单的最后一条留言
          fetchLastComments: function fetchLastComments() {},
          // 打开留言记录
          leaveMessage: function leaveMessage(aid) {
              if (aid) {
                  this.aid = aid;
              }
              this.showleavemessage = true;
          },
          uploadWork: function uploadWork() {
              (0, _jquery2['default'])('#upload').click();
          },
          verifyWork: function verifyWork(type) {
              var _this = this;
  
              var status = constant.ORDER.FIRST_MODIFY;
              if (type === 'second') {
                  status = constant.ORDER.SECOND_MODIFY;
              }
              _srcAssetsJsApi2['default'].patch({
                  url: this.url,
                  data: {
                      status: status
                  }
              }).done(function () {
                  return _this.reloadAsyncData();
              });
          },
          deleteWork: function deleteWork(index) {
              this.works.splice(index, 1);
              var works = this.works;
              _srcAssetsJsPage.Vue.set(this.works, works);
              _srcAssetsJsApi2['default'].patch({
                  url: this.url + this.id + '/',
                  data: {
                      works: works
                  }
              });
          },
          showOverlay: function showOverlay(works) {
              this.showModal = true;
              this.similarWorks = works;
          },
          // 确认合作人
          confirmOrder: function confirmOrder(id) {
              var url = constant.API.ORDERS + id + constant.API.ORDER_CONFIRM;
              _srcAssetsJsApi2['default'].patch({
                  url: url,
                  data: {
                      aid: id
                  }
              }).done(function () {
                  window.location.href = constant.PATH.ORDER_PUB_MANAGEMENT + "?status=confirmed";
              });
          }
      },
      data: function data() {
          var id = _srcAssetsJsUtils2['default'].getURLParam('id');
          var url = constant.API.ORDERS + id;
  
          return {
              reviseFile: {},
              reviseVal: '',
              evaluateVal: '',
              currentApplyRecords: {},
              userInfoVisible: false,
              url: url,
              aid: '',
              showModal: false,
              showleavemessage: false,
              last_comment: null,
              order: {
                  dynamic_info: {},
                  user: {}
              },
              works: [],
              apply_cost: '0.00',
              similarWorks: [],
              ORDER: constant.ORDER
          };
      }
  };
  module.exports = exports['default'];
  var __vue__options__;
  if(exports && exports.__esModule && exports.default){
    __vue__options__ = exports.default;
  }else{
    __vue__options__ = module.exports;
  }
  __vue__options__.template = "<dheader></dheader><modal :show.sync=\"showModal\" :css=\"{width: 640, height: 600}\"><h3 slot=\"header\" style=\"margin:0;\" class=\"fl\"><a>同类案例\t</a></h3><div slot=\"body\" __vuec__883c8210=\"__vuec__883c8210\" class=\"slot-body mt-40\"><ul class=\"works mt-30\"><li v-for=\"work in similarWorks\"><a :href=\"work[1]\" target=\"_new;\"><img :src=\"work[1]\"/></a></li></ul></div><div slot=\"footer\"></div></modal><order-user-info :info=\"currentApplyRecords\" :detail=\"order\" v-if=\"userInfoVisible\" @closeUserInfo=\"closeUserInfo\"></order-user-info><div __vuec__883c8210=\"__vuec__883c8210\" class=\"wrap\"><orderdetail :otitle=\"otitle\" :order=\"order\"></orderdetail><div v-if=\"isConfirmed\" class=\"description\"><div class=\"l\"><div class=\"avatar\"><img :src=\"order.applier.avatar\"/></div><div class=\"name\">{{order.applier.name}}</div><div class=\"exp\">3年工作经验</div><div class=\"type\">【弱电智能】【灯光设计】</div><div class=\"tel-check\"><a :href=\"`tel:${order.applier.mobile}`\"><img src=\"/src/page/order/images/ico_tel.png\" alt=\"\"/></a><span>{{order.applier.mobile}}</span></div><p>注：工作者交付稿件后五个工作日雇主未发起改稿，系统默认为订单交易结束并完成支付。</p></div><div class=\"r\"><div><div class=\"works_project_files\"><h3>工作者提交的项目文件<span>【交付稿件为初稿】</span></h3><div class=\"upload_file\"><div v-if=\"order.deliver_works[0]\" class=\"file_name\">{{order.deliver_works[0].filename}}</div><div v-else=\"v-else\" class=\"file_name\">工作者还未上传项目文件</div><a :href=\"order.deliver_works[0].file_path\" target=\"_new;\" class=\"uoloadbtn\">下载附件</a></div></div><hr/><p>注：您可以选择确认并评价或者发起改稿（为保证双方权益，仅允许发起改稿2次）</p><hr/><div v-if=\"order.deliver_works[0]\"><textarea v-if=\"order.deliver_works[0] &amp;&amp; !order.modify_works\" placeholder=\"请在此处编辑改稿内容\" v-model=\"reviseVal\" class=\"revise\"></textarea><div v-else=\"v-else\" style=\"height:150px;border:1px solid #000;\">{{order.modify_works[0].desc}}</div><div class=\"upload_file\"><p v-if=\"order.deliver_works[0] &amp;&amp; !order.modify_works\">上传改稿所需附件</p><div v-if=\"order.deliver_works[0] &amp;&amp; !order.modify_works\" class=\"file_name\">{{reviseFile[0] || '请上传附件'}}</div><div v-else=\"v-else\" class=\"file_name\">{{order.modify_works[0].filename}}</div><div @click=\"uploadZip\" v-if=\"order.deliver_works[0] &amp;&amp; !order.modify_works\" class=\"uoloadbtn\">上传附件<upload type=\"resource\"></upload></div></div><div @click=\"handleRevise\" v-if=\"order.deliver_works[0] &amp;&amp; !order.modify_works\" class=\"sendRevise\">发起改稿</div></div><hr/></div><div v-if=\"order.deliver_works[1]\"><div class=\"works_project_files\"><h3>工作者提交的项目文件<span>【交付稿件为一改】</span></h3><div class=\"upload_file\"><div v-if=\"order.deliver_works[1]\" class=\"file_name\">{{order.deliver_works[1].filename}}</div><div v-else=\"v-else\" class=\"file_name\">工作者还未上传项目文件</div><a :href=\"order.deliver_works[1].file_path\" target=\"_new;\" class=\"uoloadbtn\">下载附件</a></div></div><hr/><p>注：您可以选择确认并评价或者发起改稿（为保证双方权益，仅允许发起改稿2次）</p><hr/><div><textarea v-if=\"!order.modify_works[1]\" placeholder=\"请在此处编辑改稿内容\" v-model=\"reviseVal\" class=\"revise\"></textarea><div v-else=\"v-else\" style=\"height:150px;border:1px solid #000;\">{{order.modify_works[1].desc}}</div><div class=\"upload_file\"><p v-if=\"!order.modify_works[1]\">上传改稿所需附件</p><div v-if=\"!order.modify_works[1]\" class=\"file_name\">{{reviseFile[0] || '请上传附件'}}</div><div v-else=\"v-else\" class=\"file_name\">{{order.modify_works[1].filename}}</div><div @click=\"uploadZip\" v-if=\"!order.modify_works[1]\" class=\"uoloadbtn\">上传附件<upload type=\"resource\"></upload></div></div><div @click=\"handleRevise\" v-if=\"!order.modify_works[1]\" class=\"sendRevise\">发起改稿</div></div><hr/></div><div v-if=\"order.deliver_works[2]\"><div class=\"works_project_files\"><h3>工作者提交的项目文件<span>【交付稿件为二改】</span></h3><div class=\"upload_file\"><div v-if=\"order.deliver_works[2]\" class=\"file_name\">{{order.deliver_works[2].filename}}</div><div v-else=\"v-else\" class=\"file_name\">工作者还未上传项目文件</div><a :href=\"order.deliver_works[2].file_path\" target=\"_new;\" class=\"uoloadbtn\">下载附件</a></div></div><hr/><p>注：您可以选择确认并评价或者发起改稿（为保证双方权益，仅允许发起改稿2次）</p><hr/><div><textarea v-if=\"!order.modify_works[2]\" placeholder=\"请在此处编辑改稿内容\" v-model=\"reviseVal\" class=\"revise\"></textarea><div v-else=\"v-else\" style=\"height:150px;border:1px solid #000;\">{{order.modify_works[2].desc}}</div><div class=\"upload_file\"><p v-if=\"!order.modify_works[2]\">上传改稿所需附件</p><div v-if=\"!order.modify_works[2]\" class=\"file_name\">{{reviseFile[0] || '请上传附件'}}</div><div v-else=\"v-else\" class=\"file_name\">{{order.modify_works[2].filename}}</div><div @click=\"uploadZip\" v-if=\"!order.modify_works[2]\" class=\"uoloadbtn\">上传附件<upload type=\"resource\"></upload></div></div><div @click=\"handleRevise\" v-if=\"!order.modify_works[2]\" class=\"sendRevise\">发起改稿</div></div><hr/></div><textarea placeholder=\"请在此处编辑对工作者的评价\" v-model=\"evaluateVal\" class=\"revise\"></textarea><div @click=\"submit\" class=\"sendRevise\">确定完成</div></div></div><div v-if=\"false\" class=\"jobs-container clear\"><upload type=\"*\" maxsize=\"2*1024\" :subtype.sync=\"subtype\"></upload><div class=\"jobs container\"><div v-if=\"showFirstWork\" class=\"first\"><div class=\"label\">第一次任务交付【最多二次继续修改机会】</div><div class=\"work-name fl\"><a :href=\"order.works[0].lname\">{{order.works[0].name}}</a></div><div :class=\"{'btn-gray': disabledFirstBtn}\" class=\"btn mt-50 verify-btn\"><a @click=\"verifyWork('first')\">验证未通过继续修改</a></div></div><div v-if=\"showSecondWork\" class=\"second clear\"><div class=\"label\">第二次任务交付【仅余一次继续修改机会】</div><div class=\"work-name fl\"><a :href=\"order.works[1].lname\">{{order.works[1].name}}</a></div><div class=\"clear\"></div><div :class=\"{'btn-gray': disabledSecondBtn}\" class=\"btn mt-50 verify-btn\"><a @click=\"verifyWork('second')\">验证未通过继续修改</a></div><div class=\"clear time\">{{order.works[1].created_on}} 提交</div></div><div v-if=\"showThirdWork\" class=\"third clear\"><div class=\"label\">第三次任务交付</div><div class=\"work-name fl\"><a :href=\"order.works[2].lname\">{{order.works[2].name}}</a></div><div class=\"clear time\">{{order.works[2].created_on}} 提交</div></div></div></div><div class=\"clear\"></div><table v-if=\"showappliers\"><div v-if=\"order.apply_records.length !== 0\"><thead><th class=\"applier\">接单人</th><th class=\"applier\">竞标描述</th><th class=\"action\">操作</th><th class=\"similar\">同类案例</th><th class=\"challenge\">议价</th></thead><tbody></tbody><tr v-for=\"record in order.apply_records\"><td><div class=\"item\"><div class=\"avatar\"><img :src=\"record.user.avatar\" alt=\"\"/></div><div class=\"info\"><div class=\"item-header\"><div class=\"title\"> {{record.user.name}}</div></div><div><div class=\"exp\"> {{record.user.career}}年工作经验</div></div><div class=\"skill\">{{record.user.role}}</div></div></div></td><td style=\"font-size:12px;color:#919191;\">{{record.desc || '未填写'}}</td><td><div style=\"margin:auto\" class=\"btn w-100\"><a @click=\"showUserInfo(record)\">查看详情</a></div></td><td class=\"similar-work\"><a @click=\"showOverlay(record.works)\"><img :src=\"record.works[0]['200x150']\" v-if=\"record.works.length\"/><span>共{{record.works.length}}图片</span></a></td><td class=\"challenge\">{{record.apply_cost / 100}}积分</td></tr></div><div v-else=\"v-else\" style=\"height:100px;text-align: center;line-height: 100px;\">暂无接单人</div></table></div><dfooter></dfooter>"
  

});
