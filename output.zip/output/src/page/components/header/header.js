define('src/page/components/header/header.vue', function(require, exports, module) {

  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  
  'use strict';
  
  Object.defineProperty(exports, '__esModule', {
      value: true
  });
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _srcAssetsJsApi = require('src/assets/js/api');
  
  var _srcAssetsJsApi2 = _interopRequireDefault(_srcAssetsJsApi);
  
  var _srcAssetsJsConstant = require('src/assets/js/constant');
  
  var _srcAssetsJsConstant2 = _interopRequireDefault(_srcAssetsJsConstant);
  
  var _lodash = require('node_modules/lodash/lodash');
  
  var _lodash2 = _interopRequireDefault(_lodash);
  
  var _assetsJsEventVue = require('src/assets/js/eventVue');
  
  var _assetsJsEventVue2 = _interopRequireDefault(_assetsJsEventVue);
  
  exports['default'] = {
      // 获取users的信息
      asyncData: function asyncData(resolve) {
          var self = this;
          this.fetch().done(function () {
              localStorage.setItem("temp_user_id", this.data.id);
              _assetsJsEventVue2['default'].$emit("userinfo", this.data);
              resolve(this);
              if (self.isLogout && window.location.pathname.indexOf('/order/') > -1) {
                  window.location.href = _srcAssetsJsConstant2['default'].PATH.LOGIN;
              }
          });
      },
      computed: {
          // isHome () {
          //     return window.location.pathname === '/';
          // },
          isLogout: function isLogout() {
              return this.data && JSON.stringify(this.data) === '{}';
          }
      },
      methods: {
          fetch: function fetch() {
              var promise = _srcAssetsJsApi2['default'].get({
                  url: _srcAssetsJsConstant2['default'].API.USER_STAT
              });
              window.userStat = promise;
              return promise;
          },
          toggleMenu: function toggleMenu() {
              this.showMenu = !this.showMenu;
          },
          logout: function logout() {
              _srcAssetsJsApi2['default'].get({
                  url: _srcAssetsJsConstant2['default'].API.LOGOUT
              }).done(function () {
                  window.location.href = _srcAssetsJsConstant2['default'].PATH.HOME;
              });
          }
      },
      data: function data() {
          return _lodash2['default'].merge({}, _srcAssetsJsConstant2['default'].PATH, {
              info: {},
              data: {},
              // 未登录状态
              success: false,
              // 是否显示菜单
              showMenu: false,
              // 用户名
              name: '',
              pathname: window.location.pathname
          });
      }
  };
  module.exports = exports['default'];
  var __vue__options__;
  if(exports && exports.__esModule && exports.default){
    __vue__options__ = exports.default;
  }else{
    __vue__options__ = module.exports;
  }
  __vue__options__.template = "<header __vuec__509532dd=\"__vuec__509532dd\" class=\"header\"><div class=\"header-account\"><div class=\"container-fluid\"><div class=\"logo fl\"><a href=\"/\"><img src=\"/src/page/components/header/logo.png\"/></a></div><div class=\"router\"><ul><li :class=\"{active: pathname === '/'}\"><a href=\"/\">首页</a></li><li :class=\"{active: pathname === ORDER_DEMAND}\"><a href=\"{{ORDER_DEMAND}}\">需求池</a></li><li :class=\"{active: pathname === ORDER_PUB_MANAGEMENT}\"><a href=\"{{ORDER_PUB_MANAGEMENT}}\">我是雇主</a></li><li :class=\"{active: pathname === ORDER_APPLY_MANAGEMENT}\"><a href=\"{{ORDER_APPLY_MANAGEMENT}}\">我是工作者</a></li><li :class=\"{active: pathname === ORDER_INTEGRAL}\"><a href=\"{{ORDER_INTEGRAL}}\">积分购买</a></li><li><a href=\"{{ABOUT}}\" target=\"_blank;\">关于自由</a></li></ul></div><div class=\"account-container fr\"><div v-if=\"isLogout\" class=\"fl\"><ul class=\"login\"><li class=\"regedit\"><a href=\"{{REGISTER}}\" target=\"_blank;\">注册</a></li><li class=\"vline\">|</li><li><a href=\"{{LOGIN}}\" target=\"_blank;\">登录</a></li></ul></div><div v-else=\"v-else\" class=\"fl logon\"><div @click=\"toggleMenu\"><span class=\"fl user-display-name ellipsis\">{{data.name || ''}}</span><span class=\"fl arrow-down ml-10\">&nbsp;</span></div><div class=\"clear\"></div><ul v-show=\"showMenu\" class=\"account-menu\"><li class=\"logout\"><a href=\"{{USER_PROFILE}}\">个人中心</a></li><li @click=\"logout\" class=\"logout\"><a href=\"javascript:;\">退出</a></li></ul></div><div class=\"fl ml-20\"><input placeholder=\"Search users\" class=\"search\"/></div></div></div></div></header>"
  

});
