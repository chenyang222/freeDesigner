define('src/page/components/gallery-detail/gallery-detail.vue', function(require, exports, module) {

  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  
  'use strict';
  
  Object.defineProperty(exports, '__esModule', {
      value: true
  });
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _srcAssetsJsApi = require('src/assets/js/api');
  
  var _srcAssetsJsApi2 = _interopRequireDefault(_srcAssetsJsApi);
  
  exports['default'] = {
      data: function data() {
          return {
              galleryUserInfo: {},
              designerInfo: {
                  role: ''
              },
              galleryList: [],
              galleryListMore: [],
              nowImage: '',
              nowIndex: 0,
              styleObj: {
                  left: '0px'
              },
              galleryCommentList: [],
              inputValue: ''
          };
      },
      props: ['detail'],
      created: function created() {
          this.pageInit();
      },
      methods: {
          pageInit: function pageInit() {
              var that = this;
              var galleryid = this.detail.id;
              var userid = this.detail.uid;
              var galleryUsrUrl = '/api/users/' + userid + '/gallery/' + galleryid; // 设计师信息
              var userInfoUrl = '/api/users/' + userid; // 设计师信息
              var galleryPicUrl = '/api/users/' + userid + '/gallery/' + galleryid + '/image/'; // 图片信息
              var morePictureUrl = '/api/users/' + userid + '/gallery/'; //更多作品
              _srcAssetsJsApi2['default'].get({
                  url: galleryUsrUrl
              }).done(function () {
                  that.galleryUserInfo = this.data;
              });
              _srcAssetsJsApi2['default'].get({
                  url: userInfoUrl
              }).done(function () {
                  that.designerInfo = this.data;
              });
              _srcAssetsJsApi2['default'].get({
                  url: galleryPicUrl
              }).done(function () {
                  that.galleryList = this.data;
                  that.nowImage = this.data[0].mid_image;
                  that.nowIndex = 0;
              });
              _srcAssetsJsApi2['default'].get({
                  url: morePictureUrl
              }).done(function () {
                  console.info(this.data);
                  that.galleryListMore = this.data.galleries;
              });
              this.getComment();
          },
          closeGallery: function closeGallery() {
              this.$parent.closeGallery();
          },
          clickLike: function clickLike() {
              var that = this;
              var clickLikeUrl = '/api/like_it/' + this.detail.id; // 点赞
              _srcAssetsJsApi2['default'].post({
                  url: clickLikeUrl
              }).done(function () {
                  that.designerInfo.like_count += 1;
              });
          },
          selectImg: function selectImg(img, idx) {
              this.nowImage = img;
              this.nowIndex = idx;
              var leftPx = 0;
              if (this.nowIndex < 3) {
                  leftPx = 0;
              } else if (this.nowIndex + 3 <= this.galleryList.length) {
                  leftPx = -(this.nowIndex - 3 + 1) * 153.5;
              } else {
                  leftPx = -(this.galleryList.length - 5) * 153.5;
              }
              this.styleObj = {
                  left: leftPx + 'px'
              };
          },
          prev: function prev() {
              if (this.nowIndex - 1 < 0) {
                  return;
              }
              this.nowIndex = this.nowIndex - 1;
              this.selectImg(this.galleryList[this.nowIndex].mid_image, this.nowIndex);
          },
          next: function next() {
              if (this.nowIndex + 1 > this.galleryList.length - 1) {
                  return;
              }
              this.nowIndex = this.nowIndex + 1;
              this.selectImg(this.galleryList[this.nowIndex].mid_image, this.nowIndex);
          },
          getComment: function getComment() {
              var that = this;
              var galleryComment = '/api/gallery/' + this.detail.id + '/comment/'; // 讨论
              var dataForm = {
                  per_page: 1000
              };
              _srcAssetsJsApi2['default'].get({
                  url: galleryComment,
                  data: dataForm
              }).done(function () {
                  that.galleryCommentList = this.data;
              });
          },
          sendValue: function sendValue() {
              var that = this;
              var sendValueUrl = '/api/gallery/' + this.detail.id + '/comment/'; // 发送评论
              var userid = localStorage.getItem("temp_user_id");
              if (!userid) {
                  return;
              }
              var dataFrom = {
                  uid: userid,
                  content: this.inputValue
              };
              _srcAssetsJsApi2['default'].post({
                  url: sendValueUrl,
                  data: dataFrom
              }).done(function () {
                  that.inputValue = '';
                  that.getComment();
              });
          },
          toEngineer: function toEngineer() {
              var publicURL = constant.PATH.USER_PUB + '?uid=' + this.detail.uid;
              window.location.href = publicURL;
          },
          replaceGallery: function replaceGallery(items) {
              this.detail = items;
              this.pageInit();
          }
      }
  };
  module.exports = exports['default'];
  var __vue__options__;
  if(exports && exports.__esModule && exports.default){
    __vue__options__ = exports.default;
  }else{
    __vue__options__ = module.exports;
  }
  __vue__options__.template = "\n<div class=\"galleryDetail\" __vuec__154f4d12>\n    <div class=\"close\" @click=\"closeGallery()\">X</div>\n    <div class=\"content\">\n        <div class=\"contentbox\">\n            <div class=\"title\">{{ galleryUserInfo.name }}</div>\n            <div class=\"userInfo\">\n                <div class=\"left-info\">\n                    <div @click=\"toEngineer\" class=\"avatar\">\n                        <img :src=\"designerInfo.avatar\" alt=\"avatar\">\n                    </div>\n                    <div class=\"info\">\n                        <div class=\"name\">&nbsp;&nbsp;{{ designerInfo.name }}</div>\n                        <div class=\"box\">\n                            <span class=\"skill\" v-for=\"(idx, childItem) in designerInfo.role.split(',')\" :key=\"idx\">\n                                【{{ childItem }}】\n                            </span>\n                            <span class=\"caree\">{{ designerInfo.career }}年工作经验</span>\n                        </div>\n                    </div>\n                </div>\n                <div class=\"right-info\" @click=\"clickLike\">\n                    <span class=\"number\">{{ designerInfo.like_count }}</span>\n                    <img src=\"/src/page/components/gallery-detail/heart.png\" alt=\"heart\">\n                    <span class=\"like\">like</span>\n                </div>\n            </div>\n            <div class=\"image-content\">\n                <div class=\"showImage\" :style=\"{'background-image': 'url(' + nowImage + ')'}\"></div>\n                <div class=\"selectImage\">\n                    <div class=\"imgbox\" :style=\"styleObj\">\n                        <div @click=\"selectImg(items.mid_image, idx)\" :class=\"idx == nowIndex ? 'img active' : 'img'\" v-for=\"(idx, items) in galleryList\" :key=\"idx\">\n                            <img :src=\"items.small_image\">\n                        </div>\n                    </div>\n                </div>\n            </div>\n            <div class=\"gallery-content\">\n                <div class=\"descr\">\n                    <span class=\"descr-title\">作品说明:</span>\n                    <p class=\"descr-text\">{{ galleryUserInfo.desc }}</p>\n                </div>\n                <div class=\"more\">\n                    <span class=\"more-title\">更多作品 ...</span>\n                    <div class=\"more-content\">\n                        <div @click=\"replaceGallery(items)\" v-for=\"(idx, items) in galleryListMore.slice(0, 4)\" :key=\"idx\" :style=\"{'background-image': 'url(' + items.thumb + ')'}\"></div>\n                    </div>\n                </div>\n            </div>\n            <div class=\"talkAbout\">\n                <div class=\"talk\" v-for=\"(idx, item) in galleryCommentList\" :key=\"idx\">\n                    <div class=\"avatar\">\n                        <img :src=\"item.user_avatar\" alt=\"avatar\">\n                    </div>\n                    <div class=\"talk-info\">\n                        <div class=\"talk-name\">{{ item.username }}</div>\n                        <div class=\"talk-content\">\n                            <p>{{ item.content }}</p>\n                        </div>\n                    </div>\n                </div>\n            </div>\n            <div class=\"sendTalk\">\n                <input type=\"text\" v-model=\"inputValue\">\n                <div class=\"send\" @click=\"sendValue\">发表</div>\n            </div>\n        </div>\n        <div @click=\"prev\" class=\"prev btnStyle\">《</div>\n        <div @click=\"next\" class=\"next btnStyle\">》</div>\n    </div>\n</div>\n"
  

});
