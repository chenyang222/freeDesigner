define('src/page/app.vue', function(require, exports, module) {

  //
  //
  //
  //
  //
  //
  //
  //
  
  'use strict';
  
  Object.defineProperty(exports, '__esModule', {
      value: true
  });
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _srcAssetsJsPage = require('src/assets/js/page');
  
  var _srcPageComponentsBanner = require('src/page/components/banner/index.vue');
  
  var _srcPageComponentsBanner2 = _interopRequireDefault(_srcPageComponentsBanner);
  
  var _srcPageComponentsEngineers = require('src/page/components/engineers/index.vue');
  
  var _srcPageComponentsEngineers2 = _interopRequireDefault(_srcPageComponentsEngineers);
  
  var _srcPageComponentsHomeDemand = require('src/page/components/home-demand/index.vue');
  
  var _srcPageComponentsHomeDemand2 = _interopRequireDefault(_srcPageComponentsHomeDemand);
  
  var _srcPageComponentsHotGalleryGallery = require('src/page/components/hot-gallery/gallery.vue');
  
  var _srcPageComponentsHotGalleryGallery2 = _interopRequireDefault(_srcPageComponentsHotGalleryGallery);
  
  exports['default'] = {
      components: {
          dheader: _srcAssetsJsPage.dheader,
          dfooter: _srcAssetsJsPage.dfooter,
          hotgallery: _srcPageComponentsHotGalleryGallery2['default'],
          banner: _srcPageComponentsBanner2['default'],
          engineers: _srcPageComponentsEngineers2['default'],
          homeDemand: _srcPageComponentsHomeDemand2['default']
      },
      data: function data() {
          return {};
      }
  };
  module.exports = exports['default'];
  var __vue__options__;
  if(exports && exports.__esModule && exports.default){
    __vue__options__ = exports.default;
  }else{
    __vue__options__ = module.exports;
  }
  __vue__options__.template = "<dheader></dheader><banner></banner><engineers></engineers><home-demand></home-demand><hotgallery></hotgallery><dfooter></dfooter>"
  

});
