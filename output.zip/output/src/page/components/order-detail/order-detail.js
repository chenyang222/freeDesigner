define('src/page/components/order-detail/order-detail.vue', function(require, exports, module) {

  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  
  'use strict';
  
  Object.defineProperty(exports, '__esModule', {
      value: true
  });
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _vue = require('node_modules/vue/dist/vue.common');
  
  var _vue2 = _interopRequireDefault(_vue);
  
  var _srcAssetsJsApi = require('src/assets/js/api');
  
  var _srcAssetsJsApi2 = _interopRequireDefault(_srcAssetsJsApi);
  
  var _jquery = require('node_modules/jquery/dist/jquery');
  
  var _jquery2 = _interopRequireDefault(_jquery);
  
  var _srcAssetsJsUtils = require('src/assets/js/utils');
  
  var _srcAssetsJsUtils2 = _interopRequireDefault(_srcAssetsJsUtils);
  
  var _srcPageMixins = require('src/page/mixins');
  
  var _srcPageMixins2 = _interopRequireDefault(_srcPageMixins);
  
  _vue2['default'].filter('f2f', function (val) {
      return val ? '线上' : '线下';
  });
  _vue2['default'].filter('mesure', function (val) {
      return val ? '' : '不';
  });
  
  exports['default'] = {
      props: ['otitle', 'type', 'order'],
      mixins: [_srcPageMixins2['default']],
      data: function data() {
          return {
              user: {},
              works: []
          };
      }
  };
  module.exports = exports['default'];
  var __vue__options__;
  if(exports && exports.__esModule && exports.default){
    __vue__options__ = exports.default;
  }else{
    __vue__options__ = module.exports;
  }
  __vue__options__.template = "<div __vuec__e137513f=\"__vuec__e137513f\" class=\"wrap\"><div class=\"banner pt-40\"><div class=\"title\">{{order.title}}</div><div class=\"subtitle mt-10\">{{otitle}}</div></div><div class=\"detail\"><div class=\"main container\"><div class=\"avatar mt-30\"><a href=\"{{publicURL}}?uid={{order.user.id}}\"><img :src=\"order.user.avatar\" class=\"fl\"/></a><div class=\"clear\"></div><div class=\"name\">{{order.user.name}}</div></div><div class=\"user-desc mt-10\">{{order.user.desc}}</div><div class=\"task-desc mt-30\"><span>{{order.scate}} {{order.task_count}} {{order.task_unit}}</span><span class=\"ml-30\">交稿时间剩余：{{order.count_down}}</span></div><div class=\"dynamic-desc\"><span>建筑面积 {{order.dynamic_info.area}}平米</span><span class=\"ml-30\">{{order.dynamic_info.style}}风格</span><span class=\"ml-30\">{{order.dynamic_info.is_face2face | f2f}}</span><span class=\"ml-30\">{{order.dynamic_info.is_mesure || mesure}}包括量房</span></div><div class=\"time-desc\"><span>创建时间：{{order.created_on | date 'yy-mm-dd'}}</span><span class=\"ml-30\">交稿时间：{{order.deadline | date 'yy-mm-dd'}}</span></div><ul class=\"cost-desc mt-30\"><li><span>系统报价</span><span class=\"ml-30\">￥{{order.system_cost || 0}} 积分</span></li><li><span>已加赏金</span><span class=\"ml-30\">￥{{order.fee/100 || 0}} 积分</span></li></ul></div></div><div class=\"description\"><div class=\"project-desc container\"><div class=\"label border mt-20\">项目描述</div><div class=\"desc\">{{order.desc}}</div><div class=\"label border-top\">项目相关资料</div><div style=\"display: flex;align-items: center;\" v-for=\"item in order.files\"><div style=\"flex: 1;height: 40px;border: 1px solid #b1b1b1;background: #d6d6d6;border-radius: 10px;color: #7f7f7f;font-size: 14px;line-height: 40px;padding-left: 10px;\">{{item.filename}}</div><a style=\"display: block;width: 120px;height: 40px;line-height: 40px;color: #fff;background: #4195f7;border-radius: 6px;text-align: center;margin-left: 10px;\" :href=\"item.file_path\" target=\"_new;\">下载</a></div><div class=\"clear\"></div></div></div></div>"
  

});
