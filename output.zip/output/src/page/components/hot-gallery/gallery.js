define('src/page/components/hot-gallery/gallery.vue', function(require, exports, module) {

  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  
  'use strict';
  
  Object.defineProperty(exports, '__esModule', {
      value: true
  });
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _srcAssetsJsConstant = require('src/assets/js/constant');
  
  var _srcAssetsJsConstant2 = _interopRequireDefault(_srcAssetsJsConstant);
  
  var _srcAssetsJsApi = require('src/assets/js/api');
  
  var _srcAssetsJsApi2 = _interopRequireDefault(_srcAssetsJsApi);
  
  var _srcPageComponentsGalleryDetailGalleryDetail = require('src/page/components/gallery-detail/gallery-detail.vue');
  
  var _srcPageComponentsGalleryDetailGalleryDetail2 = _interopRequireDefault(_srcPageComponentsGalleryDetailGalleryDetail);
  
  // import overlay from '/src/page/components/gallery-overlay/overlay';
  
  exports['default'] = {
      components: {
          // overlay
          gallerydetail: _srcPageComponentsGalleryDetailGalleryDetail2['default']
      },
      asyncData: function asyncData(resolve, reject) {
          this.fetch().done(function () {
              this.gallerys = this.data.galleries;
              this.cates = this.data.cates;
              resolve(this);
          });
      },
      watch: {
          query: {
              deep: true,
              handler: function handler() {
                  this.reloadAsyncData();
              }
          }
      },
      methods: {
          // 获取基本信息
          fetch: function fetch() {
              return _srcAssetsJsApi2['default'].get({
                  url: _srcAssetsJsConstant2['default'].API.HOT_GALLERY,
                  data: this.query
              });
          },
          // 点赞功能
          likeIt: function likeIt(id) {
              var url = _srcAssetsJsConstant2['default'].API.LIKE_IT + id + '/';
              var self = this;
              _srcAssetsJsApi2['default'].post({
                  url: url
              }).done(function () {
                  self.reloadAsyncData();
              });
          },
          // 父组件向子组件派发请求
          // 弹出相册遮罩，展示详细展开包的信息，和更多相册信息
          showOverlay: function showOverlay(gallery) {
              // this.$broadcast('changeGallery', { // old gallery detail
              //     data: gallery,
              //     showModal: true
              // });
  
              // new gallery detail
              this.isShowDetail = true;
              this.detailProp = gallery;
          },
          closeGallery: function closeGallery() {
              this.isShowDetail = false;
              this.detailProp = {};
          },
          // 切换排序
          sort: function sort(e) {
              var el = e.currentTarget;
              var order = el.value;
              this.query = {
                  order_by: order
              };
          },
          // 按照分类筛选相册
          searchCate: function searchCate(e) {
              var el = e.currentTarget;
              var scate = el.value;
              this.query = {
                  scate: scate
              };
          }
      },
      data: function data() {
          var sortType = 'view_count';
          return {
              query: {
                  order_by: sortType
              },
              cates: [],
              data: {},
              info: {},
              sortType: sortType,
              success: false,
              gallerys: [],
              isShowDetail: false,
              detailProp: {}
          };
      }
  };
  module.exports = exports['default'];
  var __vue__options__;
  if(exports && exports.__esModule && exports.default){
    __vue__options__ = exports.default;
  }else{
    __vue__options__ = module.exports;
  }
  __vue__options__.template = "<div __vuec__626db447=\"__vuec__626db447\" class=\"gallery_title\">他们的作品&nbsp;&nbsp;Their works</div><div class=\"sort\"><div class=\"container\"><div class=\"condition\"><select @change=\"sort\" v-model=\"sortType\" class=\"fl\"><option value=\"created_on\" class=\"fl ml-20\">创建时间</option><option value=\"view_count\">热度</option><option value=\"like_count\">点赞</option></select><select @change=\"searchCate\"><option value=\"All\">全部</option><option v-for=\"opt in cates\" value=\"{{opt}}\">{{opt}}</option></select></div></div></div><div __vuec__626db447=\"__vuec__626db447\" class=\"wrap-inner\"><div class=\"content\"><ol class=\"gallerys\"><li v-for=\"(outter, gallery) in gallerys\"><div class=\"gallery fl\"><div class=\"wrap\"><a @click=\"showOverlay(gallery)\" href=\"javascript:;\"><img :src=\"gallery.thumb\" border=\"0\"/></a><div class=\"fr mt-10\"><span class=\"watching\">{{gallery.view_count}}</span><span @click=\"likeIt(gallery.id, gallery.uid)\" class=\"liking ml-20\">{{gallery.like_count}}</span></div></div><div class=\"avatar\"><img :src=\"gallery.user_avatar\" class=\"mt-10 fl\"/><div class=\"fl ml-20\">{{gallery.username}}</div></div></div></li></ol><div class=\"clear\"></div></div></div><gallerydetail v-if=\"isShowDetail\" :detail=\"detailProp\"></gallerydetail>"
  

});
