define('src/page/mixins', function(require, exports, module) {

  /**
    @file: components mixins
    @author: lisen04@baidu.com
  
  */
  
  'use strict';
  
  Object.defineProperty(exports, '__esModule', {
      value: true
  });
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _srcAssetsJsConstant = require('src/assets/js/constant');
  
  var _srcAssetsJsConstant2 = _interopRequireDefault(_srcAssetsJsConstant);
  
  exports['default'] = {
      data: function data() {
          return {
              data: {},
              info: {},
              success: false,
              and: '&',
              publicURL: _srcAssetsJsConstant2['default'].PATH.USER_PUB,
              demandURL: _srcAssetsJsConstant2['default'].PATH.ORDER_DEMAND
          };
      }
  };
  module.exports = exports['default'];

});
