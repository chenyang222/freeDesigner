define('src/page/order/pub.vue', function(require, exports, module) {

  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  
  'use strict';
  
  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  
  var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _srcAssetsJsPage = require('src/assets/js/page');
  
  var _srcAssetsJsApi = require('src/assets/js/api');
  
  var _srcAssetsJsApi2 = _interopRequireDefault(_srcAssetsJsApi);
  
  require('jqueryui/jquery.ui');
  
  var _srcPublicUploadUpload = require('src/public/upload/upload.vue');
  
  var _srcPublicUploadUpload2 = _interopRequireDefault(_srcPublicUploadUpload);
  
  var _jquery = require('node_modules/jquery/dist/jquery');
  
  var _jquery2 = _interopRequireDefault(_jquery);
  
  var _srcAssetsJsUtils = require('src/assets/js/utils');
  
  var _srcAssetsJsUtils2 = _interopRequireDefault(_srcAssetsJsUtils);
  
  var _srcPageMixins = require('src/page/mixins');
  
  var _srcPageMixins2 = _interopRequireDefault(_srcPageMixins);
  
  var _lodash = require('node_modules/lodash/lodash');
  
  var _lodash2 = _interopRequireDefault(_lodash);
  
  exports['default'] = {
    mixins: [_srcPageMixins2['default']],
    components: {
      dheader: _srcAssetsJsPage.dheader,
      upload: _srcPublicUploadUpload2['default']
    },
    events: {
      uploadComplete: function uploadComplete(resp) {
        var data = resp.data;
        switch (data[0][0].split('.')[1]) {
          case 'png':
          case 'jpeg':
          case 'jpg':
          case 'gif':
            data[0][3] = 'img';
            break;
          default:
            data[0][3] = 'file';
            break;
        }
        this.projectFiles.push(data[0]);
      },
      uploadProgress: function uploadProgress(e) {
        var position = e.position;
        var loaded = e.loaded;
      }
    },
    computed: {
      feeComputed: {
        get: function get() {
          return this.fee;
        },
        set: function set(val) {
          this.fee = val;
        }
      },
      pub_cost: function pub_cost() {
        var fee = parseInt(this.fee, 10) || 0;
        var sysCost = parseInt(this.system_cost, 10) || 0;
        var pubCost = fee * 100 + sysCost;
        return pubCost;
      },
      // 获得表单数据
      formData: function formData() {
        this.dynamic_info.total_cost = this.total_cost;
        this.setDynamicItems();
        var data = {
          dynamic_info: this.dynamic_info,
          scate: this.scate,
          fcate: this.fcate,
          system_cost: this.system_cost,
          location: this.location,
          extra_info: this.desc,
          style: this.style,
          pub_cost: this.pub_cost,
          deadline: this.deadline,
          task_count: this.task_count,
          task_unit: this.task_unit,
          violate_cost: this.violate_cost,
          desc: this.desc,
          fee: parseInt(this.fee, 10),
          files: this.projectFiles.length ? this.projectFiles.map(function (v) {
            return v[2];
          }).join() : this.files
        };
        return data;
      }
    },
    watch: {
      scate: function scate(val) {
        this.scateitems = this.scates[val];
      }
    },
    asyncData: function asyncData(resolve) {
      var _this = this;
  
      var self = this;
      this.fetchCategory().done(function (res) {
        resolve(this.data);
        // 默认动态必填项的
        self.scateitems = self.scates[self.scate];
      });
      if (this.id) {
        (function () {
          var orderInfo = null;
          var question = null;
          _this.fetch().done(function () {
            orderInfo = this.data;
          });
  
          _this.getQuestionList().done(function () {
            question = this.data;
          });
  
          var timer = setInterval(function () {
            if (orderInfo && question) {
              clearInterval(timer);
              if (!question.length) {
                resolve(Object.assign({}, _extends({}, orderInfo, {
                  question: {
                    a: '',
                    b: '',
                    c: '',
                    d: '',
                    e: ''
                  },
                  questionEdit: []
                })));
              } else {
                var v = question.sort(function (a, b) {
                  return a.qid - b.qid;
                });
                resolve(Object.assign({}, _extends({}, orderInfo, {
                  question: Object.assign({}, {
                    a: v[0].question,
                    b: v[1].question,
                    c: v[2].question,
                    d: v[3].question,
                    e: v[4].question
                  }),
                  questionEdit: v
                })));
              }
            }
          }, 500);
        })();
      }
    },
    ready: function ready() {
      var self = this;
      (0, _jquery2['default'])('.deadline').datepicker({
        dateFormat: "yy-mm-dd",
        onSelect: function onSelect(date) {
          self.deadline = date;
        }
      });
    },
    methods: {
      fetch: function fetch() {
        return _srcAssetsJsApi2['default'].get({
          url: this.url + this.id + '/'
        });
      },
      getQuestionList: function getQuestionList() {
        return _srcAssetsJsApi2['default'].get({
          url: '/api/orders/' + this.id + '/questions/'
        });
      },
      // 获取分类信息和动态必填项
      fetchCategory: function fetchCategory() {
        return _srcAssetsJsApi2['default'].get({
          url: constant.API.ORDER_CATEGORY,
          data: this.query
        });
      },
      // 获得系统报价
      getSysCost: function getSysCost() {
        var self = this;
        var url = constant.API.SUGGEST_PRICE;
        _srcAssetsJsApi2['default'].post({
          url: url,
          data: this.formData
        }).done(function () {
          self.system_cost = this.data.system_cost;
        });
      },
      submit: function submit() {
        var question = this.question;
        var questionEdit = this.questionEdit;
  
        var self = this;
        this.formData.pub_cost = this.formData.pub_cost - Number(this.formData.fee) * 100;
        console.info(this.formData);
        var ajax = this.id ? _srcAssetsJsApi2['default'].patch : _srcAssetsJsApi2['default'].post;
        var data = this.id ? {
          fee: this.fee,
          desc: this.desc
        } : this.formData;
        var url = this.id ? this.url + this.id + '/' : this.url;
        ajax({
          url: url,
          data: data
        }).done(function () {
          var id = this.data.id;
          if (!self.id) {
            Promise.all([Object.keys(question).map(function (v, i) {
              return _srcAssetsJsApi2['default'].post({
                url: '/api/orders/' + id + '/questions/',
                data: {
                  qid: i,
                  question: question[v]
                }
              });
            })]).then(function () {
              // setTimeout(() => {
              //   window.location.href = constant.PATH.ORDER_PUB_MANAGEMENT
              // }, 2000);
            });
          } else {
              Promise.all([questionEdit.map(function (v, i) {
                _srcAssetsJsApi2['default'].patch({
                  url: '/api/orders/' + self.id + '/questions/' + v.qid + '/',
                  data: {
                    question: question[Object.keys(question)[i]]
                  }
                });
              })]).then(function () {
                // setTimeout(() => {
                //   window.location.href = constant.PATH.ORDER_PUB_MANAGEMENT
                // }, 2000);
              });
            }
        });
      },
      uploadZip: function uploadZip() {
        (0, _jquery2['default'])('#upload').click();
      },
      // 获取动态必填项的内容
      setDynamicItems: function setDynamicItems() {
        var self = this;
        var $dynamicitems = (0, _jquery2['default'])('.dynamic-items select');
        $dynamicitems.each(function (index, item) {
          var $select = (0, _jquery2['default'])(item);
          var key = $select.data('dynamic');
          var val = $select.val().trim();
          self.dynamic_info[key] = val;
        });
      },
      resetDynamicItems: function resetDynamicItems() {
        this.setDynamicItems();
      }
    },
    data: function data() {
      var id = _srcAssetsJsUtils2['default'].getURLParam('id');
      return {
        orderType: 1,
        projectFiles: [],
        id: id,
        // 默认是订单, 如果单独的订单页面会重新渲染
        url: constant.API.ORDERS,
        title: '项目发单',
        fcates: [],
        scates: [],
        dynamic_info: {},
        fcate: '家庭室内工程',
        scate: '主案设计',
        scateitems: {},
        styles: ['简约', '现代', '中式', '欧式', '前卫', '其它'],
        units: ['张', '套', '项', '天'],
        task_unit: '套',
        task_count: '',
        extra_resource: '',
        location: '',
        extra_resource_name: '未上传文件',
        system_cost: 200,
        total_cost: 0, // 项目总价， 预算
        fee: 0,
        violate_cost: '', // 违约金
        deadline: _srcAssetsJsUtils2['default'].formatDate(new Date().getTime() + 24 * 1000 * 3600, 'yyyy-mm-dd hh:nn'),
        desc: '',
        lodash: _lodash2['default'],
        question: {
          a: '',
          b: '',
          c: '',
          d: '',
          e: ''
        }
      };
    }
  };
  module.exports = exports['default'];
  var __vue__options__;
  if(exports && exports.__esModule && exports.default){
    __vue__options__ = exports.default;
  }else{
    __vue__options__ = module.exports;
  }
  __vue__options__.template = "<dheader></dheader><div __vuec__cd1faa0e=\"__vuec__cd1faa0e\" class=\"wrap\"><div class=\"banner pt-40\"><div class=\"title\">{{title}}</div><div class=\"subtitle mt-10\">发起众包</div></div><div class=\"detail\"><ul class=\"main container\"><li><div class=\"label\">选择项目分类：</div><div class=\"fr\"><select v-model=\"fcate\" :disabled=\"this.id ? true :false\"><option v-for=\"opt in fcates\" :value=\"opt\">{{opt}}</option></select></div><div class=\"clear\"></div><div class=\"desc\">选择您的工程分类</div></li><li><div class=\"label\">选择项目需求：</div><div class=\"fr\"><select v-model=\"scate\" :disabled=\"this.id ? true :false\"><option v-for=\"(opt) in scates\" :value=\"$key\">{{$key}}</option></select></div><div class=\"clear\"></div><div class=\"desc\">选择您要发包的项目类型</div></li><li><div class=\"label\">任务量</div><div class=\"fr\"><input v-model=\"task_count\" placeholder=\"请填写数量及选择单位\" :disabled=\"this.id ? true :false\"/><select v-model=\"task_unit\" :disabled=\"this.id ? true :false\"><option v-for=\"opt in units\" :value=\"opt\">{{opt}}</option></select></div><div class=\"clear\"></div><div class=\"desc\">填写您需求的数量【如1套、5张、1项】</div></li><li v-if=\"scateitems.hasOwnProperty('area')\"><div class=\"label\">平米数</div><div class=\"fr\"><input v-model=\"dynamic_info.area\" placeholder=\"请填写建筑平米数\" @change=\"getSysCost\" :disabled=\"this.id ? true :false\"/><div class=\"area fl\">平米</div></div><div class=\"clear\"></div><div class=\"desc\">填写项目的建筑平米数</div></li><li><div class=\"label\">项目地址</div><div class=\"fr\"><input v-model=\"location\" placeholder=\"请填写项目地址\" :disabled=\"this.id ? true :false\"/></div><div class=\"clear\"></div><div class=\"desc\">请填写您项目大概位置</div></li><li class=\"h-auto\"><ul class=\"selection dynamic-items\"><li v-for=\"item in scateitems\" v-if=\"$key !== 'area'\"><div class=\"label\">{{ item }}</div><div class=\"clear\"></div><div v-if=\"$key === 'style'\" @change=\"resetDynamicItems\"><select data-dynamic=\"{{$key}}\" :disabled=\"this.id ? true :false\"><option v-for=\"opt in styles\" :value=\"opt\" selected=\"$index === 0\">{{opt}}</option></select></div><div v-else=\"v-else\"><select data-dynamic=\"{{$key}}\" @change=\"resetDynamicItems\" :disabled=\"this.id ? true :false\"><option value=\"false\" selected=\"selected\">否</option><option value=\"true\">是</option></select></div></li></ul></li><li class=\"clear\"><div class=\"label\">任务交付日期</div><div class=\"fr\"><input v-model=\"deadline\" placeholder=\"交付日期\" :disabled=\"this.id ? true :false\" class=\"deadline\"/></div><div class=\"clear\"></div><div class=\"desc\">选择您要求承接方的任务交付日期</div></li></ul><div class=\"transition\"><ul class=\"other container\"><li class=\"desc-wrap\"><div class=\"label\">其它要求及项目描述：</div><textarea v-model=\"desc\" placeholder=\"填写相关说明及要求，如：要求接单者展示同类案例，等\" class=\"desc\"></textarea></li><li><div class=\"label\">项目相关资料</div><div class=\"upload-wrap\"><div class=\"img-box\"><div v-for=\"item in projectFiles\" :key=\"$key\" class=\"img-item\"><img v-if=\"item[3] === 'img'\" :src=\"item[1]\" alt=\"\"/><span v-else=\"\">{{item[0]}}</span></div><div @click=\"uploadZip\" v-if=\"!this.id\" class=\"img-item btna\"></div><upload type=\"resource\"></upload></div></div><div class=\"clear\"></div></li><li><div class=\"label\">增加赏金（积分）</div><input placeholder=\"0.00\" v-model=\"feeComputed\" type=\"number\" @keyup=\"getSysCost | debounce 800\"/></li><li><div class=\"label\">设置问题以及试卷</div><div class=\"question_item\"><span>第一题 </span><input placeholder=\"第一题\" v-model=\"question.a\"/></div><div class=\"question_item\"><span>第二题 </span><input placeholder=\"第二题\" v-model=\"question.b\"/></div><div class=\"question_item\"><span>第三题 </span><input placeholder=\"第三题\" v-model=\"question.c\"/></div><div class=\"question_item\"><span>第四题 </span><input placeholder=\"第四题\" v-model=\"question.d\"/></div><div class=\"question_item\"><span>第五题 </span><input placeholder=\"第五题\" v-model=\"question.e\"/></div></li></ul><ul class=\"submit\"><li class=\"sys-cost\"><div class=\"label\">系统报价<div class=\"number ml-20\">{{system_cost / 100}}积分</div></div></li><li class=\"pub-cost\"><div class=\"label\">最终报价 (系统报价 {{system_cost / 100}} + 赏金 {{fee}})<div class=\"number ml-20\">{{pub_cost / 100}}积分</div></div></li><li><div class=\"btn\"><a v-if=\"!id\" @click=\"submit\">确认发单</a><a v-else=\"v-else\" @click=\"submit\">保存发单</a></div></li></ul></div></div></div>"
  

});
