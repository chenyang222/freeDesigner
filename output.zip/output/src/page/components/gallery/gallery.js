define('src/page/components/gallery/gallery.vue', function(require, exports, module) {

  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  
  'use strict';
  
  Object.defineProperty(exports, '__esModule', {
      value: true
  });
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _srcAssetsJsApi = require('src/assets/js/api');
  
  var _srcAssetsJsApi2 = _interopRequireDefault(_srcAssetsJsApi);
  
  exports['default'] = {
      props: ['ids'],
      asyncData: function asyncData(resolve, reject) {
          if (!this.ids.id || !this.ids.uid) {
              return;
          }
          this.fetch().done(function () {
              this.gallerys = this.data.galleries;
              this.cates = this.data.cates;
              resolve(this);
          });
      },
      watch: {
          // 从hot-gallery点击过来的时候，显示不同的更多相册
          ids: {
              deep: true,
              handler: function handler(val) {
                  this.url = constant.API.USER + val.uid + constant.API.GALLERY;
                  this.galleryid = val.id;
                  this.query = {
                      page: val.page || this.query.page,
                      per_page: val.per_page || this.query.per_page
                  };
                  this.reloadAsyncData();
              }
          }
      },
      methods: {
          // 获取当前用户的相册集
          fetch: function fetch() {
              return _srcAssetsJsApi2['default'].get({
                  url: this.url,
                  data: this.query
              });
          },
          // 根据相册ID展示相册里面的图片，点击遮罩更多相册的其中一个相册
          changeGallery: function changeGallery(gallery, e) {
              this.$dispatch('changeGallery', {
                  data: gallery,
                  showModal: true
              });
              e.preventDefault();
          }
      },
      data: function data() {
          return {
              query: {
                  page: this.ids.page || 1,
                  per_page: this.ids.per_page || 4
              },
              url: constant.API.USER + this.ids.uid + constant.API.GALLERY,
              galleryid: this.ids.id,
              data: [],
              info: {},
              success: false,
              gallerys: [],
              cates: []
          };
      }
  };
  module.exports = exports['default'];
  var __vue__options__;
  if(exports && exports.__esModule && exports.default){
    __vue__options__ = exports.default;
  }else{
    __vue__options__ = module.exports;
  }
  __vue__options__.template = "<div __vuec__bc87dad7=\"__vuec__bc87dad7\" class=\"gallerys\"><div v-for=\"(outter, gallery) in gallerys\" class=\"gallery fl\"><div :class=\"{active: gallery.id === galleryid}\" class=\"wrap\"><a href=\"javascript:;\" @click=\"changeGallery(gallery, $event)\"><img :src=\"gallery.thumb\" border=\"0\"/></a></div></div></div>"
  

});
