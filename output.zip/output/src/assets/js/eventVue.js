define('src/assets/js/eventVue', function(require, exports, module) {

  'use strict';
  
  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _vue = require('node_modules/vue/dist/vue.common');
  
  var _vue2 = _interopRequireDefault(_vue);
  
  exports['default'] = new _vue2['default']();
  module.exports = exports['default'];

});
