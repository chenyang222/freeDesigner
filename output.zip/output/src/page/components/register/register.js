define('src/page/components/register/register.vue', function(require, exports, module) {

  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  
  'use strict';
  
  Object.defineProperty(exports, '__esModule', {
      value: true
  });
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _srcAssetsJsConstant = require('src/assets/js/constant');
  
  var _srcAssetsJsConstant2 = _interopRequireDefault(_srcAssetsJsConstant);
  
  var _srcAssetsJsApi = require('src/assets/js/api');
  
  var _srcAssetsJsApi2 = _interopRequireDefault(_srcAssetsJsApi);
  
  exports['default'] = {
      methods: {
          register: function register() {
              var data = {
                  mobile: this.mobile,
                  password: this.password,
                  vcode: this.vcode
              };
              _srcAssetsJsApi2['default'].post({
                  url: _srcAssetsJsConstant2['default'].API.REGISTER,
                  data: data
              }).done(function () {
                  window.location.href = _srcAssetsJsConstant2['default'].PATH.LOGIN;
              });
          },
          // 获取手机验证码
          getVerifyCode: function getVerifyCode() {}
      },
      data: function data() {
          var mobile = Math.random() * 100000;
          mobile = mobile.toFixed(0);
          return {
              mobile: mobile,
              password: '123456',
              vcode: ''
          };
      }
  };
  module.exports = exports['default'];
  var __vue__options__;
  if(exports && exports.__esModule && exports.default){
    __vue__options__ = exports.default;
  }else{
    __vue__options__ = module.exports;
  }
  __vue__options__.template = "<div class=\"mt-60\"><div class=\"fl mobile\"><input v-model=\"mobile\" placeholder=\"您的手机号码\" maxlength=\"11\"/></div><div @click=\"getVerifyCode\" class=\"btn fl ml-10\"><a>获取验证码</a></div></div><div class=\"clear\"></div><div class=\"mt-70\"><div class=\"fl password\"><input v-model=\"password\" placeholder=\"设置密码 区分大小写\" maxlength=\"12\" type=\"password\"/></div></div><div class=\"clear\"></div><div class=\"mt-70\"><div class=\"fl verify-code\"><input v-model=\"vcode\" placeholder=\"输入验证码\" maxlength=\"6\"/></div><div @click=\"register\" class=\"btn fl ml-10\"><a>注册</a></div></div>"
  

});
