define('src/page/components/engineers/index.vue', function(require, exports, module) {

  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  
  'use strict';
  
  Object.defineProperty(exports, '__esModule', {
      value: true
  });
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _srcAssetsJsApi = require('src/assets/js/api');
  
  var _srcAssetsJsApi2 = _interopRequireDefault(_srcAssetsJsApi);
  
  var _srcAssetsJsConstant = require('src/assets/js/constant');
  
  var _srcAssetsJsConstant2 = _interopRequireDefault(_srcAssetsJsConstant);
  
  exports['default'] = {
      data: function data() {
          return {
              engineersList: []
          };
      },
      created: function created() {
          this.getRandomEnginerrsList();
      },
      methods: {
          getRandomEnginerrsList: function getRandomEnginerrsList() {
              var that = this;
              _srcAssetsJsApi2['default'].get({
                  url: _srcAssetsJsConstant2['default'].API.USER + '?is_recommend=True'
              }).done(function () {
                  if (this.data.length > 8) {
                      var list = that.getRandomArrayElements(this.data, 8);
                      for (var i = 0; i < list.length; i++) {
                          list[i].roleList = list[i].role.split(',').slice(0, 2);
                      }
                      that.engineersList = list;
                  } else {
                      var list = this.data;
                      for (var i = 0; i < list.length; i++) {
                          list[i].roleList = list[i].role.split(',').slice(0, 2);
                      }
                      that.engineersList = list;
                  }
              });
          },
          getRandomArrayElements: function getRandomArrayElements(arr, count) {
              // 随机获取数组中的8个
              var shuffled = arr.slice(0),
                  i = arr.length,
                  min = i - count,
                  temp,
                  index;
              while (i-- > min) {
                  index = Math.floor((i + 1) * Math.random());
                  temp = shuffled[index];
                  shuffled[index] = shuffled[i];
                  shuffled[i] = temp;
              }
              return shuffled.slice(min);
          },
          toEngineer: function toEngineer(items) {
              var publicURL = _srcAssetsJsConstant2['default'].PATH.USER_PUB + '?uid=' + items.id;
              window.location.href = publicURL;
          }
      }
  };
  module.exports = exports['default'];
  var __vue__options__;
  if(exports && exports.__esModule && exports.default){
    __vue__options__ = exports.default;
  }else{
    __vue__options__ = module.exports;
  }
  __vue__options__.template = "\n<div class=\"home__ngineer\" __vuec__9344fa2f>\n    <div class=\"home__ngineer__title\">\n        卓越的工程师们&nbsp;&nbsp;Excellent engineers\n    </div>\n    <div class=\"home__ngineer__content\">\n        <div class=\"content clearfix\">\n          <ol class=\"gallerys\">\n              <li v-for=\"items in engineersList\" :key=\"items.id\">\n                  <div class=\"item fl\" @click=\"toEngineer(items)\">\n                      <div class=\"avatar\">\n                          <img :src=\"items.avatar\">\n                      </div>\n                      <div class=\"title\">{{items.name}}</div>\n                      <div class=\"exp\">{{items.career}}年工作经验</div>\n                      <div class=\"label\" v-if=\"items.role\">\n                          <span v-for=\"(idx, childItem) in items.roleList\" :key=\"idx\">\n                              【{{ childItem }}】\n                          </span>\n                      </div>\n                  </div>\n              </li>\n          </ol>\n        </div>\n        <div class=\"changeEnginerrslist\" @click=\"getRandomEnginerrsList\">\n          <img src=\"/src/page/components/engineers/refresh.png\" alt=\"\">\n          <span>换一批</span>\n        </div>\n    </div>\n</div>\n"
  

});
