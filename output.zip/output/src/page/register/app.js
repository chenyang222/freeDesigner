define('src/page/register/app.vue', function(require, exports, module) {

  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  
  'use strict';
  
  Object.defineProperty(exports, '__esModule', {
      value: true
  });
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _srcAssetsJsPage = require('src/assets/js/page');
  
  var _srcPageComponentsRegisterRegister = require('src/page/components/register/register.vue');
  
  var _srcPageComponentsRegisterRegister2 = _interopRequireDefault(_srcPageComponentsRegisterRegister);
  
  exports['default'] = {
      components: {
          dheader: _srcAssetsJsPage.dheader,
          dfooter: _srcAssetsJsPage.dfooter,
          register: _srcPageComponentsRegisterRegister2['default']
      },
      data: function data() {
          return {
              number: '54678'
          };
      }
  };
  module.exports = exports['default'];
  var __vue__options__;
  if(exports && exports.__esModule && exports.default){
    __vue__options__ = exports.default;
  }else{
    __vue__options__ = module.exports;
  }
  __vue__options__.template = "<dheader></dheader><div class=\"transition\"><div class=\"container\"><div class=\"in-a-word\">下一刻，你将会与 {{number}} 位设计师，成为挚友</div><div class=\"join-them mt-10\"></div></div></div><div class=\"register-container\"><div class=\"container\"><div class=\"title-wrap\"><div class=\"title\">【自由】室内设计师场景的合作交易平台</div><div class=\"sub-title mt-10\">加入自由设计师合作交易平台，这里可以找到室内装饰中的各类小伙伴，</div><div class=\"sub-title\">分担各类擅长专业，并且由您与众多小伙伴共同打造强大的装饰设计圈。</div></div><register></register></div></div>"
  

});
