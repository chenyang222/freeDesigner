define('src/page/user/profile.vue', function(require, exports, module) {

  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  
  'use strict';
  
  Object.defineProperty(exports, '__esModule', {
      value: true
  });
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _srcAssetsJsPage = require('src/assets/js/page');
  
  var _srcPageUserTab = require('src/page/user/tab.vue');
  
  var _srcPageUserTab2 = _interopRequireDefault(_srcPageUserTab);
  
  var _srcPublicCutimgCutimg = require('src/public/cutimg/cutimg.vue');
  
  var _srcPublicCutimgCutimg2 = _interopRequireDefault(_srcPublicCutimgCutimg);
  
  var _srcAssetsJsUtils = require('src/assets/js/utils');
  
  var _srcAssetsJsUtils2 = _interopRequireDefault(_srcAssetsJsUtils);
  
  var _srcAssetsJsApi = require('src/assets/js/api');
  
  var _srcAssetsJsApi2 = _interopRequireDefault(_srcAssetsJsApi);
  
  var _jquery = require('node_modules/jquery/dist/jquery');
  
  var _jquery2 = _interopRequireDefault(_jquery);
  
  var _assetsJsEventVue = require('src/assets/js/eventVue');
  
  var _assetsJsEventVue2 = _interopRequireDefault(_assetsJsEventVue);
  
  exports['default'] = {
      components: {
          dheader: _srcAssetsJsPage.dheader,
          cutimg: _srcPublicCutimgCutimg2['default'],
          tab: _srcPageUserTab2['default']
      },
      asyncData: function asyncData(resolve, reject) {
          // 绑定用户信息
          window.userStat.done(function () {
              console.info(this.data);
              resolve(this.data);
          });
      },
      events: {
          // 上传图像完毕, 接受cutimg 的时间广播
          uploadComplete: function uploadComplete(e) {
              var resp = JSON.parse(e.target.responseText);
              this.avatar = resp.data['168x168'];
              this.saveAvatar();
          }
      },
      created: function created() {
          this.getUser();
      },
      methods: {
          // 获取选择的role
          getSelectRoles: function getSelectRoles() {
              var $selectedRoles = (0, _jquery2['default'])('.roles li.active');
              var roles = [];
              $selectedRoles.each(function (index, item) {
                  var role = (0, _jquery2['default'])(item).text();
                  roles.push(role);
              });
              return roles.join();
          },
          // 选择一个专业
          selecteRole: function selecteRole(e) {
              var el = e.currentTarget;
              var $el = (0, _jquery2['default'])(el);
              var role = this.role.split(',');
              var $selectedRoles = (0, _jquery2['default'])('.roles li.active');
              if ($selectedRoles.length >= 3 && !$el.hasClass('active')) {
                  return;
              }
              $el.toggleClass('active');
              var roleTxt = $el.text().trim();
              if ($el.hasClass('active')) {
                  role.push(roleTxt);
              } else {
                  role = _srcAssetsJsUtils2['default'].without(role, roleTxt);
              }
              this.role = role.join();
          },
          // 设置头像，触发cutimg组件的input[type="file"]控件的点击事件
          configAvatar: function configAvatar() {
              (0, _jquery2['default'])('#cutimg').click();
          },
          patch: function patch(data) {
              var url = this.url;
              _srcAssetsJsApi2['default'].patch({
                  url: url,
                  data: data
              });
          },
          // 保存用户设置
          save: function save() {
              var data = {
                  name: this.name,
                  desc: this.desc,
                  avatar: this.avatar,
                  role: this.role,
                  career: this.career,
                  age: this.age
              };
              this.patch(data);
          },
          saveAvatar: function saveAvatar() {
              this.patch({
                  avatar: this.avatar
              });
          },
          getUser: function getUser() {
              var _this = this;
  
              _assetsJsEventVue2['default'].$on("userinfo", function (data) {
                  //这里最好用箭头函数，不然this指向有问题
                  _this.userinfo = data;
              });
          }
  
      },
      data: function data() {
          var id = _srcAssetsJsUtils2['default'].getURLParam('id');
          var uid = _srcAssetsJsUtils2['default'].getURLParam('uid');
          var url = constant.API.USER; // + this.id + '/';
          return {
              userinfo: '',
              url: url,
              view_count: 0,
              like_count: 0,
              gender: '',
              age: '',
              id: '',
              // 头像的大小
              maxsize: 800,
              // user info start
              avatar: '',
              desc: '',
              name: '',
              role: '',
              // user info end
              allRoles: ['主案设计', '软装配饰', '造价预算', '施组编制', '效果图', '施工图', '项目经理', '风水设计', '平面规划', '声学设计', '灯光设计', '施工工长', '强电系统', '弱电系统', '水系统', '暖通系统', '消防系统', 'PPT标书'],
              ids: {
                  id: id,
                  uid: uid,
                  page: 1,
                  per_page: 100
              },
              province: '',
              available_cash_points: '',
              city: '',
              is_recommend: '',
              available_points: '',
              audit_status: '',
              download_count: '',
              career: '',
              license_pic: '',
              mobile: '',
              apply_count: '',
              paied_points: '',
              license_id: '',
              gallery_count: '',
              remaining: ''
          };
      }
  };
  module.exports = exports['default'];
  var __vue__options__;
  if(exports && exports.__esModule && exports.default){
    __vue__options__ = exports.default;
  }else{
    __vue__options__ = module.exports;
  }
  __vue__options__.template = "<dheader></dheader><div __vuec__e30647c8=\"__vuec__e30647c8\" class=\"profile\"><tab></tab><div class=\"bfc detail mt-20\"><div class=\"avatar-container\"><div class=\"avatar\"><img :src=\"avatar\"/></div><div class=\"avatar-config btn mt-20\"><a @click=\"configAvatar\">设置头像</a><cutimg :maxsize=\"maxsize\"></cutimg></div><div class=\"prompt mt-30\">JPG或PNG格式，不超过800K</div></div><div style=\"border-top:2px solid #cccccc;border-bottom:2px solid #cccccc;padding:15px 0;font-size:12px\" class=\"mt-30\"><span style=\"margin:0px 10px\"><b>资产情况：</b></span><span style=\"margin:0px 10px\">可用积分：{{userinfo.available_points}}</span><span style=\"margin:0px 10px\">可提现积分：{{userinfo.available_cash_points}}</span></div><input placeholder=\"您的尊称\" v-model=\"name\" class=\"name mt-30\"/><input placeholder=\"我的年龄\" v-model=\"age\" class=\"name mt-30\"/><input placeholder=\"从业年限\" v-model=\"career\" class=\"name mt-30\"/><textarea placeholder=\"您的简介\" v-model=\"desc\" class=\"desc mt-30\"></textarea><div class=\"professional mt-20\"><div class=\"title\">请选择承接业务类型（请最多选择三个技能）</div><ul class=\"roles\"><li v-for=\"_role in allRoles\" @click=\"selecteRole\" :class=\"{active: role.indexOf(_role) !== -1 }\">{{_role}}</li></ul></div><div class=\"clear\"></div><div @click=\"save\" class=\"save btn mt-30\"><a>保存设置</a></div></div></div>"
  

});
