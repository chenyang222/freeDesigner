define('src/page/user/public.vue', function(require, exports, module) {

  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  
  'use strict';
  
  Object.defineProperty(exports, '__esModule', {
      value: true
  });
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _srcAssetsJsPage = require('src/assets/js/page');
  
  var _srcPageComponentsUserGalleryGallery = require('src/page/components/user-gallery/gallery.vue');
  
  var _srcPageComponentsUserGalleryGallery2 = _interopRequireDefault(_srcPageComponentsUserGalleryGallery);
  
  var _srcAssetsJsUtils = require('src/assets/js/utils');
  
  var _srcAssetsJsUtils2 = _interopRequireDefault(_srcAssetsJsUtils);
  
  var _srcAssetsJsApi = require('src/assets/js/api');
  
  var _srcAssetsJsApi2 = _interopRequireDefault(_srcAssetsJsApi);
  
  var _srcPublicRadarRadar = require('src/public/radar/radar.vue');
  
  var _srcPublicRadarRadar2 = _interopRequireDefault(_srcPublicRadarRadar);
  
  exports['default'] = {
      components: {
          dheader: _srcAssetsJsPage.dheader,
          gallery: _srcPageComponentsUserGalleryGallery2['default'],
          radar: _srcPublicRadarRadar2['default']
      },
      watch: {
          roles: function roles(val) {
              console.log(val);
          }
      },
      computed: {
          roles: function roles() {
              return this.user.role.split(',');
          }
      },
      asyncData: function asyncData(resolve) {
          this.fetch().done(function () {
              this.user = this.data;
              resolve(this);
          });
      },
      methods: {
          // 获取用户基本信息
          fetch: function fetch() {
              return _srcAssetsJsApi2['default'].get({
                  url: constant.API.USER + this.ids.uid
              });
          }
      },
      data: function data() {
          var id = _srcAssetsJsUtils2['default'].getURLParam('id');
          var uid = _srcAssetsJsUtils2['default'].getURLParam('uid');
          return {
              user: {},
              ids: {
                  id: id,
                  uid: uid,
                  page: 1,
                  per_page: 100
              },
              info: {},
              data: {},
              success: false
          };
      }
  };
  module.exports = exports['default'];
  var __vue__options__;
  if(exports && exports.__esModule && exports.default){
    __vue__options__ = exports.default;
  }else{
    __vue__options__ = module.exports;
  }
  __vue__options__.template = "<dheader></dheader><div __vuec__499e8fb2=\"__vuec__499e8fb2\" class=\"profile\"><div class=\"detail fl\"><div class=\"avatar\"><img :src=\"user.avatar\"/></div><div class=\"bfc mt-40\"><div class=\"watching\"><label>浏览总量</label><div class=\"number fr mr-20\">{{user.view_count}}</div></div><div class=\"liking mt-10\"><img src=\"/src/page/components/gallery/like.png\"/><div class=\"number fr mr-20\">{{user.like_count}}</div></div></div></div><div class=\"fl desc ml-20\"><div class=\"name ml-30\">{{user.name}}</div><div class=\"slogon ml-30\">{{user.desc}}</div><div class=\"business mt-80 pl-30 pt-20\"><div class=\"label fl\">承接业务：</div><ul class=\"bfc\"><li v-for=\"r in roles\">{{r}}</li></ul></div></div><div class=\"bfc radar fr mr-30\"><radar :data=\"data\"></radar></div></div><gallery :uid=\"ids.uid\" :type=\"public\"></gallery>"
  

});
