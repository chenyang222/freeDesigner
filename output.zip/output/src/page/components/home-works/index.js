define('src/page/components/home-works/index.vue', function(require, exports, module) {

  "use strict";
  
  module.exports = {};
  var __vue__options__;
  if(exports && exports.__esModule && exports.default){
    __vue__options__ = exports.default;
  }else{
    __vue__options__ = module.exports;
  }
  __vue__options__.template = "\n<div class=\"home__works\">\n    <div class=\"home__works__title\">\n        他们的作品&nbsp;&nbsp;Their works\n    </div>\n    <div class=\"home__works__options\">\n        <div class=\"item\">\n            <select>\n                <option value=\"1\">选项A</option>\n                <option value=\"2\">选项B</option>\n                <option value=\"3\">选项C</option>\n            </select>\n            <span class=\"ico\">》</span>\n        </div>\n        <div class=\"item\">\n            <select>\n                <option value=\"1\">选项A</option>\n                <option value=\"2\">选项B</option>\n                <option value=\"3\">选项C</option>\n            </select>\n            <span class=\"ico\">》</span>\n        </div>\n    </div>\n    <div class=\"home__works__content\">\n        <div class=\"item\">\n            <div class=\"main\">\n                <div class=\"t\">\n                    <div class=\"title\">一千平米办公室</div>\n                    <div class=\"info\"></div>\n                </div>\n                <div class=\"b\">\n\n                </div>\n            </div>\n            <div class=\"name\">\n                <div class=\"avatar\"></div>\n            </div>\n        </div>\n    </div>\n</div>\n"
  

});
